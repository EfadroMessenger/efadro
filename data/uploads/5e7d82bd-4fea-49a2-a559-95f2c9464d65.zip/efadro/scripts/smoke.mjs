/**
 * efadro end-to-end smoke test.
 * Boots a real server instance on a temp config and exercises:
 * gate flow, auth, DMs, groups, WebSocket events, moderation hierarchy.
 *
 * Run: node scripts/smoke.mjs
 */
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import url from 'node:url';
import WebSocket from 'ws';

const ROOT = path.join(path.dirname(url.fileURLToPath(import.meta.url)), '..');
const PORT = 3217;
const BASE = `http://127.0.0.1:${PORT}`;

let passed = 0;
let failed = 0;
const ok = (cond, name, extra = '') => {
  if (cond) { passed++; console.log(`  ✓ ${name}`); }
  else { failed++; console.error(`  ✗ ${name} ${extra}`); }
};

async function req(method, p, { token, gate, body } = {}) {
  const headers = {};
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  if (token) headers.Authorization = `Bearer ${token}`;
  else if (gate) headers.Authorization = `Bearer ${gate}`;
  const res = await fetch(BASE + p, { method, headers, body: body !== undefined ? JSON.stringify(body) : undefined });
  let json = null;
  try { json = await res.json(); } catch { /* empty */ }
  return { status: res.status, json };
}

function wsConnect(token) {
  return new Promise((resolve, reject) => {
    const ws = new WebSocket(`${BASE.replace('http', 'ws')}/ws?token=${encodeURIComponent(token)}`);
    ws.frames = [];
    ws.waiters = [];
    ws.on('message', (raw) => {
      const f = JSON.parse(raw.toString());
      ws.frames.push(f);
      ws.waiters = ws.waiters.filter((w) => !w(f));
    });
    ws.on('open', () => resolve(ws));
    ws.on('error', reject);
  });
}
function waitFrame(ws, t, timeout = 4000, filter = () => true) {
  const existing = ws.frames.find((f) => f.t === t && filter(f));
  if (existing) return Promise.resolve(existing);
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(`timeout waiting for '${t}'`)), timeout);
    ws.waiters.push((f) => {
      if (f.t === t && filter(f)) { clearTimeout(timer); resolve(f); return true; }
      return false;
    });
  });
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/* ------------------------------------------------------------------ */

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'efadro-smoke-'));
fs.writeFileSync(path.join(tmp, 'config.json'), JSON.stringify({
  serverName: 'Smoke Server',
  host: '127.0.0.1',
  port: PORT,
  serverPassword: 's3cret-pass',
  jwtSecret: 'smoke-test-secret-0123456789abcdef0123456789abcdef',
  owner: { username: 'owner', password: 'bootstrap-owner-pass' },
  turnstile: { enabled: false, siteKey: '', secretKey: '' },
  registration: { enabled: true },
  rateLimit: { enabled: false },
}, null, 2));

console.log('\nefadro smoke test\n=================\n');
const child = spawn(process.execPath, ['server/index.js'], {
  cwd: ROOT,
  env: { ...process.env, EFADRO_CONFIG: path.join(tmp, 'config.json') },
  stdio: ['ignore', 'pipe', 'pipe'],
});
child.stderr.on('data', (d) => process.stderr.write(`[server] ${d}`));

let exitCode = 0;
try {
  // wait for boot
  let info = null;
  for (let i = 0; i < 60; i++) {
    try { const r = await fetch(BASE + '/api/info'); info = await r.json(); break; }
    catch { await sleep(250); }
  }
  if (!info) throw new Error('server did not start');

  console.log('• Server info & gates');
  ok(info.product === 'efadro', 'info identifies as efadro');
  ok(info.name === 'Smoke Server', 'server name from config');
  ok(info.serverPasswordRequired === true, 'server password flagged as required');
  ok(info.turnstile.enabled === false, 'turnstile disabled');

  const noPass = await req('POST', '/api/gate', { body: {} });
  ok(noPass.status === 403, 'gate rejects missing password');
  const wrongPass = await req('POST', '/api/gate', { body: { serverPassword: 'nope' } });
  ok(wrongPass.status === 403, 'gate rejects wrong password');
  const goodGate = await req('POST', '/api/gate', { body: { serverPassword: 's3cret-pass' } });
  ok(goodGate.status === 200 && goodGate.json.gateToken, 'gate issues token with correct password');
  const gate = goodGate.json.gateToken;

  console.log('• Auth');
  const noGateSignup = await req('POST', '/api/auth/signup', { body: { username: 'xuser', password: 'password123' } });
  ok(noGateSignup.status === 401, 'signup blocked without gate token');
  const badUser = await req('POST', '/api/auth/signup', { gate, body: { username: 'no spaces!', password: 'password123' } });
  ok(badUser.status === 400, 'invalid username rejected');
  const shortPw = await req('POST', '/api/auth/signup', { gate, body: { username: 'alice', password: 'short' } });
  ok(shortPw.status === 400, 'short password rejected');

  const signup = async (u) => (await req('POST', '/api/auth/signup', { gate, body: { username: u, password: `${u}-password-1`, displayName: u[0].toUpperCase() + u.slice(1) } })).json;
  const alice = await signup('alice');
  const bob = await signup('bob');
  const carol = await signup('carol');
  ok(alice?.token && bob?.token && carol?.token, 'three users registered');
  const dup = await req('POST', '/api/auth/signup', { gate, body: { username: 'ALICE', password: 'password1234' } });
  ok(dup.status === 409, 'duplicate username (case-insensitive) rejected');

  const ownerLogin = await req('POST', '/api/auth/login', { gate, body: { username: 'owner', password: 'bootstrap-owner-pass' } });
  ok(ownerLogin.status === 200 && ownerLogin.json.user.role === 'owner', 'owner from config.json logs in with owner role');
  const owner = ownerLogin.json;
  const wrongLogin = await req('POST', '/api/auth/login', { gate, body: { username: 'alice', password: 'wrong' } });
  ok(wrongLogin.status === 401, 'wrong login rejected');

  const meA = await req('GET', '/api/auth/me', { token: alice.token });
  ok(meA.status === 200 && meA.json.user.username === 'alice', 'GET /me works');

  console.log('• Chats & messages (REST)');
  const dmRes = await req('POST', '/api/chats/dm', { token: alice.token, body: { userId: bob.user.id } });
  ok(dmRes.status === 200 && dmRes.json.chat.type === 'dm', 'alice creates DM with bob');
  const dm = dmRes.json.chat;
  const dmDup = await req('POST', '/api/chats/dm', { token: bob.token, body: { userId: alice.user.id } });
  ok(dmDup.json.chat.id === dm.id, 'DM is reused, not duplicated');
  const bobChats = await req('GET', '/api/chats', { token: bob.token });
  ok(bobChats.json.chats.some((c) => c.id === dm.id), 'bob sees the DM in his list');

  const m1 = await req('POST', `/api/chats/${dm.id}/messages`, { token: alice.token, body: { content: 'hello bob!' } });
  ok(m1.status === 201 && m1.json.message.content === 'hello bob!', 'alice sends a message');
  const longMsg = await req('POST', `/api/chats/${dm.id}/messages`, { token: alice.token, body: { content: 'x'.repeat(5000) } });
  ok(longMsg.status === 400, 'over-length message rejected');
  const bobUnread = await req('GET', '/api/chats', { token: bob.token });
  ok(bobChats && bobUnread.json.chats.find((c) => c.id === dm.id)?.unread === 1, 'bob has 1 unread message');
  const bobMsgs = await req('GET', `/api/chats/${dm.id}/messages`, { token: bob.token });
  ok(bobMsgs.json.messages.length === 1, 'bob reads message history');
  const bobUnread2 = await req('GET', '/api/chats', { token: bob.token });
  ok(bobUnread2.json.chats.find((c) => c.id === dm.id)?.unread === 0, 'unread cleared after fetching history');

  const outsiderMsg = await req('POST', `/api/chats/${dm.id}/messages`, { token: carol.token, body: { content: 'im not in this chat' } });
  ok(outsiderMsg.status === 403, 'non-member cannot post to the DM');

  const edited = await req('PATCH', `/api/messages/${m1.json.message.id}`, { token: alice.token, body: { content: 'hello bob (edited)' } });
  ok(edited.status === 200 && edited.json.message.editedAt, 'author edits message');
  const editOther = await req('PATCH', `/api/messages/${m1.json.message.id}`, { token: bob.token, body: { content: 'hax' } });
  ok(editOther.status === 403, 'non-author cannot edit');

  console.log('• WebSocket realtime');
  const wsBob = await wsConnect(bob.token); // bob first so alice's ready frame already lists him
  const wsAlice = await wsConnect(alice.token);
  const readyA = await waitFrame(wsAlice, 'ready');
  ok(readyA.data.user.username === 'alice', 'ws ready frame carries self');
  ok(readyA.data.online.includes(bob.user.id), 'ready frame includes currently-online users');
  const presP = waitFrame(wsAlice, 'presence', 4000, (f) => f.data.userId === bob.user.id && f.data.online === true);
  const wsBob2 = await wsConnect(bob.token); // second device
  await presP;
  ok(true, 'presence broadcast works', '');
  wsBob2.close();

  const wsMsgP = waitFrame(wsBob, 'msg:new', 4000, (f) => f.data.message.chatId === dm.id);
  await req('POST', `/api/chats/${dm.id}/messages`, { token: alice.token, body: { content: 'via rest → ws' } });
  const wsMsg = await wsMsgP;
  ok(wsMsg.data.message.content === 'via rest → ws', 'REST send reaches WS listeners');

  const wsSendP = waitFrame(wsAlice, 'msg:new', 4000, (f) => f.data.message.content === 'via ws → ws');
  wsBob.send(JSON.stringify({ t: 'msg:send', data: { chatId: dm.id, content: 'via ws → ws', clientId: 'c1' } }));
  await wsSendP;
  ok(true, 'WS send reaches other members');

  const typingP = waitFrame(wsAlice, 'typing', 4000, (f) => f.data.user.username === 'bob');
  wsBob.send(JSON.stringify({ t: 'typing', data: { chatId: dm.id, typing: true } }));
  await typingP;
  ok(true, 'typing indicator delivered');

  const readP = waitFrame(wsAlice, 'read', 4000, (f) => f.data.userId === bob.user.id);
  const lastId = (await req('GET', `/api/chats/${dm.id}/messages`, { token: bob.token })).json.messages.at(-1).id;
  wsBob.send(JSON.stringify({ t: 'read', data: { chatId: dm.id, messageId: lastId } }));
  const readF = await readP;
  ok(readF.data.messageId === lastId, 'read receipts synchronized');
  const dmAfterRead = (await req('GET', `/api/chats/${dm.id}`, { token: alice.token })).json.chat;
  ok(dmAfterRead.members.find((m) => m.id === bob.user.id)?.lastRead === lastId, 'peer lastRead updates (seen ✓✓)');

  console.log('• Groups');
  const grp = (await req('POST', '/api/chats/group', {
    token: alice.token, body: { name: 'Test Group', memberIds: [bob.user.id, carol.user.id] },
  })).json.chat;
  ok(grp?.type === 'group' && grp.members.length === 3, 'group created with 3 members');
  const wsCarol = await wsConnect(carol.token);
  const grpMsgP = waitFrame(wsCarol, 'msg:new', 4000, (f) => f.data.message.chatId === grp.id);
  wsBob.send(JSON.stringify({ t: 'msg:send', data: { chatId: grp.id, content: 'group hello' } }));
  await grpMsgP;
  ok(true, 'group message broadcast to all members');
  const chatNewP = waitFrame(wsCarol, 'chat:updated', 4000, (f) => f.data.chat.id === grp.id);
  await req('PATCH', `/api/chats/${grp.id}`, { token: bob.token, body: { name: 'Renamed Group' } });
  await chatNewP;
  ok(true, 'group rename broadcast');
  const ghost = await req('POST', `/api/chats/${grp.id}/messages`, { token: bob.token, body: { content: 'still here' } });
  ok(ghost.status === 201, 'member posts in group');

  console.log('• Saved messages');
  const saved = (await req('POST', '/api/chats/dm', { token: carol.token, body: { userId: carol.user.id } })).json.chat;
  ok(saved?.type === 'dm' && saved.members.length === 1, 'self-chat (saved messages) works');

  console.log('• Moderation hierarchy');
  const bobAdminTry = await req('GET', '/api/admin/users', { token: bob.token });
  ok(bobAdminTry.status === 403, 'regular user blocked from staff API');

  const promMod = await req('PATCH', `/api/admin/users/${alice.user.id}/role`, { token: owner.token, body: { role: 'moderator' } });
  ok(promMod.status === 200 && promMod.json.user.role === 'moderator', 'owner promotes alice → moderator');
  const selfFrameP = waitFrame(wsAlice, 'user:self', 4000, (f) => f.data.user.role === 'moderator');
  ok((await selfFrameP).data.user.role === 'moderator', 'role change pushed live to the user');

  const banByMod = await req('POST', `/api/admin/users/${bob.user.id}/ban`, { token: alice.token, body: {} });
  ok(banByMod.status === 403, 'moderator cannot ban');

  const muteByMod = await req('POST', `/api/admin/users/${bob.user.id}/mute`, { token: alice.token, body: { minutes: 10, reason: 'test mute' } });
  ok(muteByMod.status === 200 && muteByMod.json.user.mutedUntil > Date.now(), 'moderator mutes bob');
  const mutedPost = await req('POST', `/api/chats/${dm.id}/messages`, { token: bob.token, body: { content: 'am i muted?' } });
  ok(mutedPost.status === 403 && mutedPost.json.code === 'muted', 'muted user cannot send messages');

  const modBanOwner = await req('POST', `/api/admin/users/${owner.user.id}/mute`, { token: alice.token, body: { minutes: 5 } });
  ok(modBanOwner.status === 403, 'moderator cannot touch the owner (hierarchy)');

  const unmute = await req('POST', `/api/admin/users/${bob.user.id}/unmute`, { token: alice.token, body: {} });
  ok(unmute.status === 200 && unmute.json.user.mutedUntil === 0, 'unmute works');

  const delOtherAsMember = await req('DELETE', `/api/messages/${ghost.json.message.id}`, { token: carol.token });
  ok(delOtherAsMember.status === 403, 'regular user cannot delete others’ messages');
  const delAsMod = await req('DELETE', `/api/messages/${ghost.json.message.id}`, { token: alice.token });
  ok(delAsMod.status === 200, 'moderator deletes lower-role user’s message');
  const deletedGone = await req('GET', `/api/chats/${grp.id}/messages`, { token: bob.token });
  ok(!deletedGone.json.messages.some((m) => m.id === ghost.json.message.id), 'deleted message disappears from history');

  console.log('• Admin actions');
  const promAdmin = await req('PATCH', `/api/admin/users/${alice.user.id}/role`, { token: owner.token, body: { role: 'admin' } });
  ok(promAdmin.status === 200, 'owner promotes alice → admin');
  const selfRoleOwner = await req('PATCH', `/api/admin/users/${owner.user.id}/role`, { token: owner.token, body: { role: 'user' } });
  ok(selfRoleOwner.status === 400, 'owner cannot change their own role');
  const banCarol = await req('POST', `/api/admin/users/${carol.user.id}/ban`, { token: alice.token, body: { reason: 'rule 1' } });
  ok(banCarol.status === 200 && banCarol.json.user.banned === true, 'admin bans carol');
  const carolApi = await req('GET', '/api/chats', { token: carol.token });
  ok(carolApi.status === 401, 'banned user’s token is invalidated');
  const carolLogin = await req('POST', '/api/auth/login', { gate, body: { username: 'carol', password: 'carol-password-1' } });
  ok(carolLogin.status === 403 && carolLogin.json.code === 'banned', 'banned login gives clear reason');
  const kf = wsCarol.frames.find((f) => f.t === 'force_logout');
  ok(Boolean(kf), 'banned user received force_logout push');
  const unbanCarol = await req('POST', `/api/admin/users/${carol.user.id}/unban`, { token: alice.token, body: {} });
  ok(unbanCarol.status === 200, 'unban works');
  const carolRelogin = await req('POST', '/api/auth/login', { gate, body: { username: 'carol', password: 'carol-password-1' } });
  ok(carolRelogin.status === 200, 'unbanned user can sign in again');

  const kickBob = await req('POST', `/api/admin/users/${bob.user.id}/kick`, { token: alice.token, body: {} });
  ok(kickBob.status === 200, 'kick signs out sessions');
  await sleep(150);
  const bobAfterKick = await req('GET', '/api/chats', { token: bob.token });
  ok(bobAfterKick.status === 401, 'kicked user token invalidated');

  const bootstrapProtect = await req('POST', `/api/admin/users/${owner.user.id}/ban`, { token: alice.token, body: {} });
  ok(bootstrapProtect.status === 403, 'bootstrap owner cannot be banned');

  console.log('• Reports & audit');
  const bobFresh = await loginFresh(gate, 'bob');
  ok(bobFresh?.token, 'kicked user can sign in again');
  const ownReport = await req('POST', `/api/messages/${lastId}/report`, { token: bobFresh.token, body: { reason: 'spam' } });
  ok(ownReport.status === 400, 'users cannot report their own message');
  const report = await req('POST', `/api/messages/${m1.json.message.id}/report`, { token: bobFresh.token, body: { reason: 'spam' } });
  ok(report.status === 200, 'report submitted');
  const repList = await req('GET', '/api/admin/reports', { token: alice.token });
  ok(repList.status === 200 && repList.json.reports.length >= 1, 'moderator+ sees open reports');
  const repId = repList.json.reports[0]?.id;
  const resolve = await req('POST', `/api/admin/reports/${repId}/resolve`, { token: alice.token, body: {} });
  ok(resolve.status === 200, 'report resolved');
  const audit = await req('GET', '/api/admin/audit', { token: alice.token });
  ok(audit.status === 200 && audit.json.entries.some((e) => e.action === 'ban'), 'audit log records moderation actions');
  const stats = await req('GET', '/api/admin/stats', { token: alice.token });
  ok(stats.status === 200 && stats.json.stats.users >= 4, 'stats endpoint works');

  console.log('• Server config (owner panel)');
  const srvCfg = await req('GET', '/api/admin/server/config', { token: owner.token });
  ok(srvCfg.status === 200 && srvCfg.json.config.jwtSecretMasked.includes('•'), 'owner reads masked server config');
  const srvCfgDenied = await req('GET', '/api/admin/server/config', { token: bobFresh.token });
  ok(srvCfgDenied.status === 403, 'non-owner cannot read server config');
  const upd = await req('PATCH', '/api/admin/server/config', { token: owner.token, body: { serverName: 'Renamed Server', registrationEnabled: false } });
  ok(upd.status === 200, 'owner patches server config');
  const info2 = await (await fetch(BASE + '/api/info')).json();
  ok(info2.name === 'Renamed Server' && info2.registrationEnabled === false, 'live config applied to /api/info');
  const savedCfg = JSON.parse(fs.readFileSync(path.join(tmp, 'config.json'), 'utf8'));
  ok(savedCfg.serverName === 'Renamed Server' && savedCfg.registration.enabled === false, 'config.json persisted to disk');
  const regClosed = await req('POST', '/api/auth/signup', { gate, body: { username: 'dave', password: 'dave-password-1' } });
  ok(regClosed.status === 403, 'registration toggle enforced');
  await req('PATCH', '/api/admin/server/config', { token: owner.token, body: { registrationEnabled: true } });

  console.log('• Secret rotation');
  const rotate = await req('POST', '/api/admin/server/regenerate-secret', { token: owner.token, body: {} });
  ok(rotate.status === 200, 'owner rotates JWT secret');
  await sleep(250);
  const stale = await req('GET', '/api/auth/me', { token: owner.token });
  ok(stale.status === 401, 'all sessions invalidated after rotation');
  const relogin = await req('POST', '/api/auth/login', { gate, body: { username: 'owner', password: 'bootstrap-owner-pass' } });
  ok(relogin.status === 401 && relogin.json.code === 'gate', 'old gate tokens also die after rotation');
  const freshGate = (await req('POST', '/api/gate', { body: { serverPassword: 's3cret-pass' } })).json.gateToken;
  const relogin2 = await req('POST', '/api/auth/login', { gate: freshGate, body: { username: 'owner', password: 'bootstrap-owner-pass' } });
  ok(relogin2.status === 200, 'fresh gate → login works after rotation');

  console.log('• Static frontend');
  const html = await (await fetch(BASE + '/')).text();
  ok(html.includes('/js/app.js') && html.includes('efadro'), 'index.html served at /');
  const js = await fetch(BASE + '/js/app.js');
  ok(js.status === 200 && (js.headers.get('content-type') || '').includes('javascript'), 'app.js served');
  const css = await fetch(BASE + '/css/style.css');
  ok(css.status === 200, 'style.css served');
  const csp = (await fetch(BASE + '/')).headers.get('content-security-policy');
  ok(Boolean(csp && csp.includes('challenges.cloudflare.com')), 'CSP allows Turnstile');
} catch (e) {
  failed++;
  console.error('\nFATAL during smoke test:', e);
  exitCode = 1;
} finally {
  child.kill('SIGTERM');
}

async function loginFresh(gate, u) {
  return (await req('POST', '/api/auth/login', { gate, body: { username: u, password: `${u}-password-1` } })).json;
}

if (exitCode === 0) exitCode = failed > 0 ? 1 : 0;
console.log(`\n=================\n${passed} passed, ${failed} failed\n`);
process.exit(exitCode);
