import * as store from './store.js';
import { HttpError, vStr, now } from './util.js';

/**
 * Chat/message business logic shared between REST endpoints and the WebSocket
 * hub, including the real-time fan-out so both transports behave identically.
 */

/** Send a message (validates membership, mute status, length). Returns the created message. */
export function postMessage(user, chatId, rawContent, limits) {
  const chat = store.getChat(chatId);
  if (!chat) throw new HttpError(404, 'Chat not found');
  if (!store.isMember(chatId, user.id)) throw new HttpError(403, 'You are not a member of this chat');
  if (user.muted_until > now()) {
    throw new HttpError(403, `You are muted until ${new Date(user.muted_until).toISOString()}`, {
      code: 'muted', mutedUntil: user.muted_until, reason: user.mute_reason,
    });
  }
  const content = vStr(String(rawContent ?? ''), {
    label: 'Message', min: 1, max: limits?.maxMessageLength ?? 4000,
  });
  const message = store.createMessage({ chatId, userId: user.id, content });
  return { chat, message };
}

/** Broadcast a fresh per-member chat payload to all members. */
export function emitChatToMembers(hub, chatId, { type = 'chat:updated', onlyUserIds = null, excludeUserId = null } = {}) {
  const members = store.getMembers(chatId);
  for (const m of members) {
    if (onlyUserIds && !onlyUserIds.includes(m.id)) continue;
    if (excludeUserId && m.id === excludeUserId) continue;
    const payload = store.chatPayloadFor(chatId, m.id);
    if (payload) hub.sendToUser(m.id, { t: type, data: { chat: payload } });
  }
}

/** Broadcast a new message to every chat member (sender included — client dedupes / reconciles). */
export function emitNewMessage(hub, chatId, message, clientId = null) {
  const members = store.getMembers(chatId);
  hub.sendToUsers(members.map((m) => m.id), { t: 'msg:new', data: { message, clientId } });
}

export function emitMessageEdited(hub, chatId, message) {
  const members = store.getMembers(chatId);
  hub.sendToUsers(members.map((m) => m.id), { t: 'msg:edited', data: { message } });
}

export function emitMessageDeleted(hub, chatId, messageId, byMod) {
  const members = store.getMembers(chatId);
  hub.sendToUsers(members.map((m) => m.id), { t: 'msg:deleted', data: { chatId, messageId, byMod } });
}

export function emitRead(hub, chatId, userId, messageId) {
  const members = store.getMembers(chatId);
  hub.sendToUsers(members.map((m) => m.id), { t: 'read', data: { chatId, userId, messageId } });
}

/** Edit a message — only the author may edit. */
export function editMessageAs(user, messageId, rawContent, limits) {
  const msg = store.getMessage(messageId);
  if (!msg) throw new HttpError(404, 'Message not found');
  if (msg.author.id !== user.id) throw new HttpError(403, 'You can only edit your own messages');
  const content = vStr(String(rawContent ?? ''), {
    label: 'Message', min: 1, max: limits?.maxMessageLength ?? 4000,
  });
  store.editMessage(messageId, content);
  return store.getMessage(messageId);
}

/**
 * Delete a message — the author always may; staff may delete messages of
 * strictly-lower-role members; the group creator may delete inside their group.
 */
export function deleteMessageAs(actor, messageId, roleLevelFn) {
  const msg = store.getMessage(messageId);
  if (!msg) throw new HttpError(404, 'Message not found');
  const chat = store.getChat(msg.chatId);
  const isAuthor = msg.author.id === actor.id;
  const isStaff = roleLevelFn(actor.role) > roleLevelFn(msg.author.role) && roleLevelFn(actor.role) >= 1;
  const isChatCreator = chat && chat.created_by === actor.id && chat.type === 'group';
  if (!isAuthor && !isStaff && !isChatCreator) throw new HttpError(403, 'Not allowed to delete this message');
  const byMod = !isAuthor;
  store.softDeleteMessage(messageId, byMod);
  if (byMod) store.audit(actor.id, 'message_delete', msg.author.id, { messageId, chatId: msg.chatId });
  return { chatId: msg.chatId, byMod };
}

/** Mark messages as read (idempotent, monotone). */
export function markRead(user, chatId, messageId) {
  if (!store.isMember(chatId, user.id)) throw new HttpError(403, 'You are not a member of this chat');
  const id = Number(messageId);
  if (!Number.isInteger(id) || id < 0) throw new HttpError(400, 'Invalid message id');
  store.setLastRead(chatId, user.id, id);
  return id;
}
