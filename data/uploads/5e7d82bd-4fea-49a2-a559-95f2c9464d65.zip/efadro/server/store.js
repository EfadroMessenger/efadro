import { db } from './db.js';
import { newId, now, avatarColorFor } from './util.js';

/* ============================= USERS ============================= */

const qUserById = db.prepare('SELECT * FROM users WHERE id = ?');
const qUserByName = db.prepare('SELECT * FROM users WHERE username = ?');

export const getUserById = (id) => qUserById.get(id);
export const getUserByUsername = (username) => qUserByName.get(String(username));

export function createUser({ username, displayName, passwordHash, role = 'user' }) {
  const id = newId();
  db.prepare(`INSERT INTO users (id, username, display_name, password_hash, role, avatar_color, created_at, last_seen)
              VALUES (?, ?, ?, ?, ?, ?, ?, ?)`)
    .run(id, username, displayName, passwordHash, role, avatarColorFor(id), now(), now());
  return getUserById(id);
}

export function updateUser(id, patch) {
  const allowed = ['display_name', 'password_hash', 'role', 'banned', 'ban_reason', 'banned_at', 'muted_until', 'mute_reason', 'token_version'];
  const sets = [];
  const vals = [];
  for (const k of allowed) {
    if (k in patch) { sets.push(`${k} = ?`); vals.push(patch[k]); }
  }
  if (!sets.length) return getUserById(id);
  db.prepare(`UPDATE users SET ${sets.join(', ')} WHERE id = ?`).run(...vals, id);
  return getUserById(id);
}

export const touchLastSeen = (id, ts = now()) => db.prepare('UPDATE users SET last_seen = ? WHERE id = ?').run(ts, id);

export function searchUsers(q, limit = 20, excludeId = null) {
  const like = `%${String(q || '').trim()}%`;
  return db.prepare(`SELECT * FROM users
                     WHERE banned = 0 AND (username LIKE ? OR display_name LIKE ?) ${excludeId ? 'AND id != ?' : ''}
                     ORDER BY username COLLATE NOCASE LIMIT ?`)
    .all(like, like, ...(excludeId ? [excludeId] : []), limit);
}

export function listUsers({ q = '', limit = 300, offset = 0 } = {}) {
  const like = `%${q}%`;
  return db.prepare(`SELECT * FROM users
                     WHERE username LIKE ? OR display_name LIKE ?
                     ORDER BY CASE role WHEN 'owner' THEN 0 WHEN 'admin' THEN 1 WHEN 'moderator' THEN 2 ELSE 3 END,
                              username COLLATE NOCASE
                     LIMIT ? OFFSET ?`).all(like, like, limit, offset);
}

/* ---- JSON views ---- */

export function publicUser(u) {
  if (!u) return null;
  return {
    id: u.id,
    username: u.username,
    displayName: u.display_name,
    role: u.role,
    avatarColor: u.avatar_color,
    lastSeen: u.last_seen,
  };
}

export function selfUser(u) {
  return {
    ...publicUser(u),
    createdAt: u.created_at,
    mutedUntil: u.muted_until,
    muteReason: u.mute_reason,
  };
}

export function adminUser(u) {
  return {
    ...selfUser(u),
    banned: Boolean(u.banned),
    banReason: u.ban_reason,
    bannedAt: u.banned_at,
  };
}

/* ============================= CHATS ============================= */

export const getChat = (id) => db.prepare('SELECT * FROM chats WHERE id = ?').get(id);
export const getDmByKey = (key) => db.prepare('SELECT * FROM chats WHERE dm_key = ?').get(key);

export const isMember = (chatId, userId) =>
  Boolean(db.prepare('SELECT 1 FROM chat_members WHERE chat_id = ? AND user_id = ?').get(chatId, userId));

export function getMembers(chatId) {
  return db.prepare(`SELECT u.*, cm.last_read AS last_read, cm.joined_at AS joined_at
                     FROM chat_members cm JOIN users u ON u.id = cm.user_id
                     WHERE cm.chat_id = ?
                     ORDER BY u.username COLLATE NOCASE`).all(chatId);
}

export function createChat({ type, name = '', dmKey = null, createdBy, memberIds }) {
  const id = newId();
  const ts = now();
  const tx = db.transaction(() => {
    db.prepare('INSERT INTO chats (id, type, name, dm_key, created_by, created_at) VALUES (?,?,?,?,?,?)')
      .run(id, type, name, dmKey, createdBy, ts);
    const ins = db.prepare('INSERT OR IGNORE INTO chat_members (chat_id, user_id, joined_at) VALUES (?,?,?)');
    for (const uid of new Set(memberIds)) ins.run(id, uid, ts);
  });
  tx();
  return getChat(id);
}

export function addMembers(chatId, userIds) {
  const ts = now();
  const ins = db.prepare('INSERT OR IGNORE INTO chat_members (chat_id, user_id, joined_at) VALUES (?,?,?)');
  const added = [];
  const tx = db.transaction(() => {
    for (const uid of userIds) {
      if (ins.run(chatId, uid, ts).changes > 0) added.push(uid);
    }
  });
  tx();
  return added;
}

export function removeMember(chatId, userId) {
  db.prepare('DELETE FROM chat_members WHERE chat_id = ? AND user_id = ?').run(chatId, userId);
  const remaining = db.prepare('SELECT COUNT(*) AS c FROM chat_members WHERE chat_id = ?').get(chatId).c;
  if (remaining === 0) db.prepare('DELETE FROM chats WHERE id = ?').run(chatId);
  return remaining;
}

export const renameChat = (chatId, name) => db.prepare('UPDATE chats SET name = ? WHERE id = ?').run(name, chatId);

const MESSAGE_VIEW = `
  SELECT m.id, m.chat_id AS chatId, m.content, m.created_at AS createdAt, m.edited_at AS editedAt,
         u.id AS a_id, u.username AS a_username, u.display_name AS a_displayName,
         u.role AS a_role, u.avatar_color AS a_avatarColor
  FROM messages m JOIN users u ON u.id = m.user_id`;

function mapMessageRow(r) {
  return {
    id: r.id,
    chatId: r.chatId,
    content: r.content,
    createdAt: r.createdAt,
    editedAt: r.editedAt ?? null,
    author: {
      id: r.a_id,
      username: r.a_username,
      displayName: r.a_displayName,
      role: r.a_role,
      avatarColor: r.a_avatarColor,
    },
  };
}

export function createMessage({ chatId, userId, content }) {
  const res = db.prepare('INSERT INTO messages (chat_id, user_id, content, created_at) VALUES (?,?,?,?)')
    .run(chatId, userId, content, now());
  return getMessage(res.lastInsertRowid);
}

export function getMessage(id) {
  const r = db.prepare(`${MESSAGE_VIEW} WHERE m.id = ? AND m.deleted = 0`).get(id);
  return r ? mapMessageRow(r) : null;
}

export function listMessages(chatId, { before = Infinity, limit = 40 } = {}) {
  const rows = db.prepare(`${MESSAGE_VIEW}
    WHERE m.chat_id = ? AND m.deleted = 0 AND m.id < ?
    ORDER BY m.id DESC LIMIT ?`).all(chatId, before, limit + 1);
  const hasMore = rows.length > limit;
  const slice = rows.slice(0, limit).reverse();
  return { messages: slice.map(mapMessageRow), hasMore };
}

export const editMessage = (id, content) =>
  db.prepare('UPDATE messages SET content = ?, edited_at = ? WHERE id = ?').run(content, now(), id);

export const softDeleteMessage = (id, byMod) =>
  db.prepare('UPDATE messages SET deleted = 1, deleted_by_mod = ? WHERE id = ?').run(byMod ? 1 : 0, id);

export function setLastRead(chatId, userId, messageId) {
  db.prepare('UPDATE chat_members SET last_read = MAX(last_read, ?) WHERE chat_id = ? AND user_id = ?')
    .run(messageId, chatId, userId);
}

/** Full chat payloads (per-user: unread differs) for every member of a chat. */
export function chatPayloadFor(chatId, userId) {
  const c = getChat(chatId);
  if (!c) return null;
  const cm = db.prepare('SELECT last_read FROM chat_members WHERE chat_id = ? AND user_id = ?').get(chatId, userId);
  if (!cm) return null;
  const unread = db.prepare(`SELECT COUNT(*) AS c FROM messages
                             WHERE chat_id = ? AND deleted = 0 AND id > ? AND user_id != ?`)
    .get(chatId, cm.last_read, userId).c;
  const lm = db.prepare(`${MESSAGE_VIEW}
    WHERE m.chat_id = ? AND m.deleted = 0 AND m.id = (SELECT MAX(id) FROM messages WHERE chat_id = ? AND deleted = 0)`)
    .get(chatId, chatId);
  return {
    id: c.id,
    type: c.type,
    name: c.name,
    createdBy: c.created_by,
    createdAt: c.created_at,
    unread,
    myLastRead: cm.last_read,
    lastMessage: lm ? mapMessageRow(lm) : null,
    members: getMembers(chatId).map((m) => ({ ...publicUser(m), lastRead: m.last_read })),
  };
}

export function listChatsForUser(userId) {
  const rows = db.prepare(`SELECT c.id FROM chats c
                           JOIN chat_members cm ON cm.chat_id = c.id AND cm.user_id = ?
                           ORDER BY COALESCE((SELECT MAX(created_at) FROM messages WHERE chat_id = c.id AND deleted = 0), c.created_at) DESC`)
    .all(userId);
  return rows.map((r) => chatPayloadFor(r.id, userId)).filter(Boolean);
}

/* ============================= REPORTS ============================= */

export function createReport({ messageId, reporterId, reason }) {
  const res = db.prepare('INSERT INTO reports (message_id, reporter_id, reason, created_at) VALUES (?,?,?,?)')
    .run(messageId, reporterId, reason, now());
  return res.lastInsertRowid;
}

export function listReports(limit = 100) {
  return db.prepare(`
    SELECT r.id, r.reason, r.status, r.created_at AS createdAt,
           m.id AS msg_id, m.chat_id AS msg_chatId, m.content AS msg_content, m.created_at AS msg_createdAt, m.deleted AS msg_deleted,
           au.id AS a_id, au.username AS a_username, au.display_name AS a_displayName,
           ru.id AS r_id, ru.username AS r_username, ru.display_name AS r_displayName
    FROM reports r
    JOIN messages m ON m.id = r.message_id
    JOIN users au ON au.id = m.user_id
    JOIN users ru ON ru.id = r.reporter_id
    WHERE r.status = 'open'
    ORDER BY r.id DESC LIMIT ?`).all(limit)
    .map((r) => ({
      id: r.id,
      reason: r.reason,
      createdAt: r.createdAt,
      message: {
        id: r.msg_id, chatId: r.msg_chatId, content: r.msg_content,
        createdAt: r.msg_createdAt, deleted: Boolean(r.msg_deleted),
      },
      author: { id: r.a_id, username: r.a_username, displayName: r.a_displayName },
      reporter: { id: r.r_id, username: r.r_username, displayName: r.r_displayName },
    }));
}

export const getReport = (id) =>
  db.prepare(`SELECT r.*, m.user_id AS author_id, m.chat_id FROM reports r JOIN messages m ON m.id = r.message_id WHERE r.id = ?`).get(id);

export const resolveReport = (id, resolverId) =>
  db.prepare(`UPDATE reports SET status = 'resolved', resolved_by = ?, resolved_at = ? WHERE id = ?`).run(resolverId, now(), id);

/* ============================= AUDIT ============================= */

export function audit(actorId, action, targetId = '', meta = {}) {
  db.prepare('INSERT INTO audit_log (actor_id, action, target_id, meta, created_at) VALUES (?,?,?,?,?)')
    .run(actorId, action, targetId, JSON.stringify(meta), now());
}

export function listAudit(limit = 100) {
  return db.prepare(`
    SELECT a.id, a.action, a.meta, a.created_at AS createdAt,
           au.username AS actor_username, au.display_name AS actor_displayName,
           tu.username AS target_username, tu.display_name AS target_displayName
    FROM audit_log a
    LEFT JOIN users au ON au.id = a.actor_id
    LEFT JOIN users tu ON tu.id = a.target_id
    ORDER BY a.id DESC LIMIT ?`).all(limit)
    .map((r) => ({
      id: r.id,
      action: r.action,
      meta: safeJson(r.meta),
      createdAt: r.createdAt,
      actor: r.actor_username ? { username: r.actor_username, displayName: r.actor_displayName } : null,
      target: r.target_username ? { username: r.target_username, displayName: r.target_displayName } : null,
    }));
}

function safeJson(s) { try { return JSON.parse(s); } catch { return {}; } }

/* ============================= STATS ============================= */

export function stats() {
  const g = (sql) => db.prepare(sql).get().c;
  return {
    users: g('SELECT COUNT(*) AS c FROM users'),
    chats: g('SELECT COUNT(*) AS c FROM chats'),
    messages: g('SELECT COUNT(*) AS c FROM messages WHERE deleted = 0'),
    banned: g('SELECT COUNT(*) AS c FROM users WHERE banned = 1'),
    openReports: g(`SELECT COUNT(*) AS c FROM reports WHERE status = 'open'`),
    online: 0, // filled by hub at runtime
  };
}

/* ======================= BOOTSTRAP OWNER SYNC ======================= */

export function bumpAllTokenVersions() {
  db.prepare('UPDATE users SET token_version = token_version + 1').run();
}
