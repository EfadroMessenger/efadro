import { Router } from 'express';
import * as store from '../store.js';
import { requireAuth } from '../auth.js';

export function usersRouter(cfg, hub) {
  const r = Router();
  r.use(requireAuth(cfg));

  r.get('/search', (req, res) => {
    const q = String(req.query.q || '').trim();
    if (q.length < 1 || q.length > 64) return res.json({ users: [] });
    const users = store.searchUsers(q, 20, req.user.id).map((u) => ({
      ...store.publicUser(u),
      online: hub.online(u.id),
    }));
    res.json({ users });
  });

  return r;
}
