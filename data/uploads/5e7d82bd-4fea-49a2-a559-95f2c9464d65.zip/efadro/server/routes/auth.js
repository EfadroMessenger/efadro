import { Router } from 'express';
import bcrypt from 'bcryptjs';
import * as store from '../store.js';
import { asyncH, makeLimiter, vStr, USERNAME_RE, HttpError } from '../util.js';
import { requireAuth, requireGate, signAccessToken } from '../auth.js';

const BCRYPT_ROUNDS = 12;

export function authRouter(cfg, hub) {
  const r = Router();
  const authLimiter = makeLimiter({
    windowMs: cfg.rateLimit?.windowMs ?? 60000,
    max: cfg.rateLimit?.authPerMinute ?? 20,
    message: 'Too many attempts, try again later',
    enabled: cfg.rateLimit?.enabled !== false,
  });

  r.post('/signup', authLimiter, requireGate(cfg), asyncH(async (req, res) => {
    if (!cfg.registration?.enabled) throw new HttpError(403, 'Registration is disabled on this server');
    const username = vStr(req.body?.username, {
      label: 'Username', min: 3, max: 24, re: USERNAME_RE,
      reMsg: 'Username may only contain letters, numbers and underscores (3–24 chars)',
    });
    const password = vStr(req.body?.password, { label: 'Password', min: 8, max: 128 });
    const displayName = vStr(req.body?.displayName, {
      label: 'Display name', min: 0, max: cfg.limits?.maxDisplayNameLength ?? 40, optional: true,
    }) || username;

    if (store.getUserByUsername(username)) throw new HttpError(409, 'This username is already taken');
    const passwordHash = await bcrypt.hash(password, BCRYPT_ROUNDS);
    const user = store.createUser({ username, displayName, passwordHash });
    store.audit(user.id, 'signup', user.id, { username });
    res.status(201).json({ token: signAccessToken(user, cfg), user: store.selfUser(user) });
  }));

  r.post('/login', authLimiter, requireGate(cfg), asyncH(async (req, res) => {
    const username = vStr(req.body?.username, { label: 'Username', min: 1, max: 24 });
    const password = vStr(req.body?.password, { label: 'Password', min: 1, max: 128 });
    const user = store.getUserByUsername(username);
    const ok = user && await bcrypt.compare(password, user.password_hash);
    if (!ok) throw new HttpError(401, 'Invalid username or password');
    if (user.banned) {
      throw new HttpError(403, 'This account is banned', { code: 'banned', reason: user.ban_reason });
    }
    store.touchLastSeen(user.id);
    res.json({ token: signAccessToken(user, cfg), user: store.selfUser(user) });
  }));

  r.get('/me', requireAuth(cfg), (req, res) => {
    res.json({ user: store.selfUser(req.user) });
  });

  r.patch('/me', requireAuth(cfg), asyncH(async (req, res) => {
    const displayName = vStr(req.body?.displayName, {
      label: 'Display name', min: 1, max: cfg.limits?.maxDisplayNameLength ?? 40,
    });
    const user = store.updateUser(req.user.id, { display_name: displayName });
    hub.broadcast({ t: 'user:updated', data: { user: store.publicUser(user) } });
    res.json({ user: store.selfUser(user) });
  }));

  r.post('/change-password', authLimiter, requireAuth(cfg), asyncH(async (req, res) => {
    const current = vStr(req.body?.current, { label: 'Current password', min: 1, max: 128 });
    const next = vStr(req.body?.next, { label: 'New password', min: 8, max: 128 });
    const ok = await bcrypt.compare(current, req.user.password_hash);
    if (!ok) throw new HttpError(403, 'Current password is incorrect');
    const passwordHash = await bcrypt.hash(next, BCRYPT_ROUNDS);
    const user = store.updateUser(req.user.id, {
      password_hash: passwordHash,
      token_version: req.user.token_version + 1, // invalidate every other session
    });
    hub.forceLogoutUser(user.id, 'Password changed');
    store.audit(user.id, 'password_change', user.id);
    res.json({ token: signAccessToken(user, cfg), user: store.selfUser(user) });
  }));

  return r;
}
