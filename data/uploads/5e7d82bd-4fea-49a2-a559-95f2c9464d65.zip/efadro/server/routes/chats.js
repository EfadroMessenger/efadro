import { Router } from 'express';
import * as store from '../store.js';
import * as services from '../services.js';
import { asyncH, vStr, vInt, makeLimiter, HttpError, roleLevel } from '../util.js';
import { requireAuth } from '../auth.js';

export function chatsRouter(cfg, hub) {
  const r = Router();
  r.use(requireAuth(cfg));

  const msgLimiter = makeLimiter({
    windowMs: 60000,
    max: cfg.rateLimit?.messagePerMinute ?? 120,
    keyFn: (req) => req.user.id,
    message: 'You are sending messages too fast',
    enabled: cfg.rateLimit?.enabled !== false,
  });

  /* ------------------------------ chats ------------------------------ */

  r.get('/', (req, res) => {
    res.json({ chats: store.listChatsForUser(req.user.id) });
  });

  r.post('/dm', asyncH(async (req, res) => {
    const targetId = vStr(req.body?.userId, { label: 'userId', min: 1, max: 64 });
    if (targetId === req.user.id) {
      // "Saved Messages" self-chat
      let chat = store.getDmByKey(`self:${req.user.id}`);
      if (!chat) {
        chat = store.createChat({ type: 'dm', dmKey: `self:${req.user.id}`, createdBy: req.user.id, memberIds: [req.user.id] });
        services.emitChatToMembers(hub, chat.id, { type: 'chat:new' });
      }
      return res.json({ chat: store.chatPayloadFor(chat.id, req.user.id) });
    }
    const target = store.getUserById(targetId);
    if (!target) throw new HttpError(404, 'User not found');
    if (target.banned) throw new HttpError(403, 'This user is banned');
    const key = [req.user.id, targetId].sort().join(':');
    let chat = store.getDmByKey(key);
    if (!chat) {
      chat = store.createChat({ type: 'dm', dmKey: key, createdBy: req.user.id, memberIds: [req.user.id, targetId] });
      services.emitChatToMembers(hub, chat.id, { type: 'chat:new' });
    }
    res.json({ chat: store.chatPayloadFor(chat.id, req.user.id) });
  }));

  r.post('/group', asyncH(async (req, res) => {
    const name = vStr(req.body?.name, { label: 'Group name', min: 1, max: cfg.limits?.maxGroupNameLength ?? 64 });
    const memberIds = Array.isArray(req.body?.memberIds) ? req.body.memberIds.map(String) : [];
    const maxSize = cfg.limits?.maxGroupSize ?? 100;
    const unique = [...new Set(memberIds)].filter((id) => id !== req.user.id);
    if (unique.length + 1 > maxSize) throw new HttpError(400, `Groups are limited to ${maxSize} members`);
    for (const id of unique) {
      const u = store.getUserById(id);
      if (!u) throw new HttpError(404, 'One of the users does not exist');
      if (u.banned) throw new HttpError(403, `${u.username} is banned and cannot be added`);
    }
    const chat = store.createChat({ type: 'group', name, createdBy: req.user.id, memberIds: [req.user.id, ...unique] });
    services.emitChatToMembers(hub, chat.id, { type: 'chat:new' });
    res.status(201).json({ chat: store.chatPayloadFor(chat.id, req.user.id) });
  }));

  r.get('/:id', asyncH(async (req, res) => {
    if (!store.isMember(req.params.id, req.user.id)) throw new HttpError(404, 'Chat not found');
    res.json({ chat: store.chatPayloadFor(req.params.id, req.user.id) });
  }));

  r.patch('/:id', asyncH(async (req, res) => {
    const chat = store.getChat(req.params.id);
    if (!chat || !store.isMember(chat.id, req.user.id)) throw new HttpError(404, 'Chat not found');
    if (chat.type !== 'group') throw new HttpError(400, 'Only groups can be renamed');
    const name = vStr(req.body?.name, { label: 'Group name', min: 1, max: cfg.limits?.maxGroupNameLength ?? 64 });
    store.renameChat(chat.id, name);
    services.emitChatToMembers(hub, chat.id);
    res.json({ chat: store.chatPayloadFor(chat.id, req.user.id) });
  }));

  r.post('/:id/members', asyncH(async (req, res) => {
    const chat = store.getChat(req.params.id);
    if (!chat || !store.isMember(chat.id, req.user.id)) throw new HttpError(404, 'Chat not found');
    if (chat.type !== 'group') throw new HttpError(400, 'Cannot add members to a direct chat');
    const ids = Array.isArray(req.body?.userIds) ? [...new Set(req.body.userIds.map(String))] : [];
    if (!ids.length) throw new HttpError(400, 'No users specified');
    const maxSize = cfg.limits?.maxGroupSize ?? 100;
    const current = store.getMembers(chat.id).length;
    if (current + ids.length > maxSize) throw new HttpError(400, `Groups are limited to ${maxSize} members`);
    for (const id of ids) {
      const u = store.getUserById(id);
      if (!u) throw new HttpError(404, 'One of the users does not exist');
      if (u.banned) throw new HttpError(403, `${u.username} is banned and cannot be added`);
    }
    const added = store.addMembers(chat.id, ids);
    services.emitChatToMembers(hub, chat.id, { type: 'chat:new', onlyUserIds: added });
    services.emitChatToMembers(hub, chat.id, { excludeUserId: null });
    res.json({ chat: store.chatPayloadFor(chat.id, req.user.id), added });
  }));

  r.delete('/:id/members/:uid', asyncH(async (req, res) => {
    const chat = store.getChat(req.params.id);
    if (!chat || !store.isMember(chat.id, req.user.id)) throw new HttpError(404, 'Chat not found');
    if (chat.type !== 'group') throw new HttpError(400, 'Cannot leave a direct chat');
    const targetId = req.params.uid;
    if (targetId !== req.user.id && chat.created_by !== req.user.id) {
      throw new HttpError(403, 'Only the group creator can remove other members');
    }
    const remaining = store.removeMember(chat.id, targetId);
    hub.sendToUser(targetId, { t: 'chat:removed', data: { chatId: chat.id } });
    if (remaining > 0) services.emitChatToMembers(hub, chat.id);
    res.json({ ok: true });
  }));

  /* ----------------------------- messages ----------------------------- */

  r.get('/:id/messages', asyncH(async (req, res) => {
    const chatId = req.params.id;
    if (!store.isMember(chatId, req.user.id)) throw new HttpError(404, 'Chat not found');
    const before = req.query.before !== undefined ? vInt(req.query.before, { label: 'before', min: 1 }) : Infinity;
    const limit = vInt(req.query.limit, { label: 'limit', min: 1, max: 100, def: 40 });
    const { messages, hasMore } = store.listMessages(chatId, { before, limit });
    const maxId = messages.length ? messages[messages.length - 1].id : 0;
    if (maxId > 0) {
      store.setLastRead(chatId, req.user.id, maxId);
      services.emitRead(hub, chatId, req.user.id, maxId);
    }
    res.json({ messages, hasMore });
  }));

  r.post('/:id/messages', msgLimiter, asyncH(async (req, res) => {
    const { chat, message } = services.postMessage(req.user, req.params.id, req.body?.content, cfg.limits);
    services.emitNewMessage(hub, chat.id, message, req.body?.clientId ?? null);
    res.status(201).json({ message });
  }));

  r.post('/:id/read', asyncH(async (req, res) => {
    const id = services.markRead(req.user, req.params.id, req.body?.messageId);
    services.emitRead(hub, req.params.id, req.user.id, id);
    res.json({ ok: true, messageId: id });
  }));

  return r;
}

/* Standalone message operations: /api/messages/... */
export function messagesRouter(cfg, hub) {
  const r = Router();
  r.use(requireAuth(cfg));

  r.patch('/:id', asyncH(async (req, res) => {
    const message = services.editMessageAs(req.user, vInt(req.params.id, { label: 'id', min: 1 }), req.body?.content, cfg.limits);
    services.emitMessageEdited(hub, message.chatId, message);
    res.json({ message });
  }));

  r.delete('/:id', asyncH(async (req, res) => {
    const { chatId, byMod } = services.deleteMessageAs(
      req.user, vInt(req.params.id, { label: 'id', min: 1 }), roleLevel,
    );
    services.emitMessageDeleted(hub, chatId, Number(req.params.id), byMod);
    res.json({ ok: true });
  }));

  r.post('/:id/report', asyncH(async (req, res) => {
    const msgId = vInt(req.params.id, { label: 'id', min: 1 });
    const reason = vStr(req.body?.reason, { label: 'Reason', min: 0, max: 500, optional: true });
    const msg = store.getMessage(msgId);
    if (!msg) throw new HttpError(404, 'Message not found');
    if (!store.isMember(msg.chatId, req.user.id)) throw new HttpError(403, 'Not your chat');
    if (msg.author.id === req.user.id) throw new HttpError(400, 'You cannot report your own message');
    store.createReport({ messageId: msgId, reporterId: req.user.id, reason });
    res.json({ ok: true });
  }));

  return r;
}
