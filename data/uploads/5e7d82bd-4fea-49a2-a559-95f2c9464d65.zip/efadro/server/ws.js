import { WebSocketServer } from 'ws';
import * as store from './store.js';
import * as services from './services.js';
import { authenticateWs } from './auth.js';
import { now } from './util.js';

/**
 * WebSocket hub: tracks online users and fans out real-time events.
 *
 * Client -> server frames (JSON):
 *   {t:'msg:send', data:{chatId, content, clientId?}}
 *   {t:'typing',   data:{chatId, typing:boolean}}
 *   {t:'read',     data:{chatId, messageId}}
 *   {t:'ping'}
 *
 * Server -> client frames:
 *   ready, msg:new, msg:edited, msg:deleted, chat:new, chat:updated,
 *   chat:removed, presence, typing, read, user:self, user:updated,
 *   server:updated, force_logout, error, pong
 */
export function createHub(server, cfg) {
  const sockets = new Map(); // userId -> Set<ws>
  const wss = new WebSocketServer({ noServer: true });

  function send(ws, obj) {
    if (ws.readyState === ws.OPEN) {
      try { ws.send(JSON.stringify(obj)); } catch { /* ignore */ }
    }
  }

  const hub = {
    online(userId) { return sockets.has(userId) && sockets.get(userId).size > 0; },
    onlineIds() { return [...sockets.keys()].filter((id) => hub.online(id)); },
    onlineCount() { return hub.onlineIds().length; },
    sendToUser(userId, obj) {
      const set = sockets.get(userId);
      if (set) for (const ws of set) send(ws, obj);
    },
    sendToUsers(userIds, obj) { for (const id of userIds) hub.sendToUser(id, obj); },
    broadcast(obj) { for (const id of sockets.keys()) hub.sendToUser(id, obj); },
    forceLogoutUser(userId, reason = 'Session terminated') {
      const set = sockets.get(userId);
      if (!set) return;
      for (const ws of set) {
        send(ws, { t: 'force_logout', data: { reason } });
        try { ws.close(4001, 'force_logout'); } catch { /* ignore */ }
      }
    },
    forceLogoutAll(reason = 'Server restarted authentication') {
      for (const id of sockets.keys()) hub.forceLogoutUser(id, reason);
    },
  };

  server.on('upgrade', (req, socket, head) => {
    let url;
    try { url = new URL(req.url, 'http://localhost'); } catch { socket.destroy(); return; }
    if (url.pathname !== '/ws') { socket.destroy(); return; }
    const user = authenticateWs(url.searchParams.get('token'), cfg);
    if (!user) {
      socket.write('HTTP/1.1 401 Unauthorized\r\n\r\n');
      socket.destroy();
      return;
    }
    wss.handleUpgrade(req, socket, head, (ws) => {
      ws.userId = user.id;
      wss.emit('connection', ws, req, user);
    });
  });

  wss.on('connection', (ws, req, user) => {
    if (!sockets.has(user.id)) sockets.set(user.id, new Set());
    sockets.get(user.id).add(ws);
    store.touchLastSeen(user.id);

    send(ws, { t: 'ready', data: { user: store.selfUser(store.getUserById(user.id)), online: hub.onlineIds() } });
    hub.broadcast({ t: 'presence', data: { userId: user.id, online: true, lastSeen: now() } });

    // Per-socket throttles
    const msgTimes = [];
    const typingTimes = [];
    const limited = (arr, max, windowMs) => {
      const cutoff = Date.now() - windowMs;
      while (arr.length && arr[0] < cutoff) arr.shift();
      if (arr.length >= max) return true;
      arr.push(Date.now());
      return false;
    };

    ws.on('message', (raw) => {
      let frame;
      try {
        if (raw.length > 8192) throw new Error('too big');
        frame = JSON.parse(raw.toString());
      } catch {
        return send(ws, { t: 'error', data: { message: 'Malformed frame' } });
      }
      const { t, data = {} } = frame || {};
      const freshUser = store.getUserById(user.id); // role/mute state is read live
      try {
        switch (t) {
          case 'ping':
            send(ws, { t: 'pong' });
            break;

          case 'msg:send': {
            const perMin = cfg.rateLimit?.enabled === false ? Infinity : (cfg.rateLimit?.messagePerMinute ?? 120);
            if (limited(msgTimes, perMin, 60000)) {
              return send(ws, { t: 'error', data: { message: 'You are sending messages too fast' } });
            }
            const { chat, message } = services.postMessage(freshUser, String(data.chatId || ''), data.content, cfg.limits);
            services.emitNewMessage(hub, chat.id, message, data.clientId ?? null);
            break;
          }

          case 'typing': {
            if (limited(typingTimes, 6, 3000)) return;
            const chatId = String(data.chatId || '');
            if (!store.isMember(chatId, freshUser.id)) return;
            const members = store.getMembers(chatId);
            for (const m of members) {
              if (m.id === freshUser.id) continue;
              hub.sendToUser(m.id, {
                t: 'typing',
                data: { chatId, user: store.publicUser(freshUser), typing: Boolean(data.typing) },
              });
            }
            break;
          }

          case 'read': {
            const id = services.markRead(freshUser, String(data.chatId || ''), data.messageId);
            services.emitRead(hub, String(data.chatId || ''), freshUser.id, id);
            break;
          }

          default:
            send(ws, { t: 'error', data: { message: `Unknown frame type: ${String(t)}` } });
        }
      } catch (e) {
        send(ws, { t: 'error', data: { message: e.message || 'Error', status: e.status || 500 } });
      }
    });

    ws.on('close', () => {
      const set = sockets.get(user.id);
      if (set) {
        set.delete(ws);
        if (set.size === 0) {
          sockets.delete(user.id);
          store.touchLastSeen(user.id);
          hub.broadcast({ t: 'presence', data: { userId: user.id, online: false, lastSeen: now() } });
        }
      }
    });

    ws.on('error', () => { /* socket errors are followed by close */ });
  });

  return hub;
}
