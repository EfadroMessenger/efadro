/* ============================================================
   efadro — frontend application
   Vanilla JS SPA: server picker → captcha → server password →
   login/signup → real-time chat + moderation panels.
   ============================================================ */

'use strict';

/* ----------------------------- helpers ----------------------------- */

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
}[c]));

const ROLE_LEVEL = { user: 0, moderator: 1, admin: 2, owner: 3 };
const roleLevel = (r) => ROLE_LEVEL[r] ?? 0;

const pad2 = (n) => String(n).padStart(2, '0');

function fmtTime(ts) {
  const d = new Date(ts);
  return `${pad2(d.getHours())}:${pad2(d.getMinutes())}`;
}
function fmtDay(ts) {
  const d = new Date(ts);
  const today = new Date();
  const yest = new Date(); yest.setDate(today.getDate() - 1);
  if (d.toDateString() === today.toDateString()) return 'Today';
  if (d.toDateString() === yest.toDateString()) return 'Yesterday';
  return d.toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: d.getFullYear() === today.getFullYear() ? undefined : 'numeric' });
}
function fmtListTime(ts) {
  const d = new Date(ts);
  if (d.toDateString() === new Date().toDateString()) return fmtTime(ts);
  return d.toLocaleDateString(undefined, { day: 'numeric', month: 'short' });
}
function timeAgo(ts) {
  const s = Math.max(1, Math.floor((Date.now() - ts) / 1000));
  if (s < 60) return `${s}s ago`;
  const m = Math.floor(s / 60); if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60); if (h < 24) return `${h}h ago`;
  const dd = Math.floor(h / 24); if (dd < 30) return `${dd}d ago`;
  return new Date(ts).toLocaleDateString();
}
function fmtLastSeen(ts) {
  if (!ts) return 'offline';
  return `last seen ${timeAgo(ts)}`;
}

const initials = (name) => (String(name || '?').trim()[0] || '?').toUpperCase();

/* ------------------------------- icons ------------------------------- */

const ic = (paths, size = 18) =>
  `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${paths}</svg>`;

const icons = {
  send: ic('<line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>', 20),
  smile: ic('<circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><line x1="9" y1="9" x2="9.01" y2="9"/><line x1="15" y1="9" x2="15.01" y2="9"/>', 20),
  search: ic('<circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>', 16),
  plus: ic('<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>', 18),
  users: ic('<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>', 18),
  user: ic('<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>', 18),
  gear: ic('<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/>', 18),
  shield: ic('<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>', 18),
  logout: ic('<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>', 18),
  back: ic('<polyline points="15 18 9 12 15 6"/>', 20),
  down: ic('<polyline points="6 9 12 15 18 9"/>', 16),
  x: ic('<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>', 16),
  check: ic('<polyline points="20 6 9 17 4 12"/>', 14),
  checks: ic('<polyline points="1.5 12.5 5.5 16.5 16 6"/><polyline points="10 14.5 12.5 17 21.5 8" opacity="0.55"/>', 14),
  trash: ic('<polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>', 14),
  pencil: ic('<path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/>', 14),
  flag: ic('<path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/><line x1="4" y1="22" x2="4" y2="15"/>', 14),
  dots: ic('<circle cx="12" cy="12" r="1" fill="currentColor"/><circle cx="12" cy="5" r="1" fill="currentColor"/><circle cx="12" cy="19" r="1" fill="currentColor"/>', 18),
  ban: ic('<circle cx="12" cy="12" r="10"/><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"/>', 15),
  mute: ic('<polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><line x1="23" y1="9" x2="17" y2="15"/><line x1="17" y1="9" x2="23" y2="15"/>', 15),
  kick: ic('<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><line x1="17" y1="8" x2="23" y2="14"/><line x1="23" y1="8" x2="17" y2="14"/>', 15),
  moon: ic('<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>', 16),
  sun: ic('<circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>', 16),
  copy: ic('<rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>', 14),
  globe: ic('<circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>', 18),
  eye: ic('<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>', 15),
  eyeOff: ic('<path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/>', 15),
  refresh: ic('<polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/>', 15),
  lock: ic('<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>', 18),
  key: ic('<path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"/>', 16),
  warn: ic('<path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>', 16),
  chat: ic('<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>', 34),
  crown: ic('<path d="M2 18h20l-2-10-5 4-3-7-3 7-5-4z"/><line x1="3" y1="22" x2="21" y2="22"/>', 13),
  activity: ic('<polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>', 15),
};

/* ------------------------------ toasts ------------------------------ */

function toast(message, type = 'info', ms = 3400) {
  const root = $('#toasts');
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  const icn = type === 'success' ? icons.check : type === 'error' ? icons.warn : icons.activity;
  el.innerHTML = `<span class="t-icon">${icn}</span><span>${esc(message)}</span>`;
  root.appendChild(el);
  setTimeout(() => {
    el.classList.add('out');
    setTimeout(() => el.remove(), 260);
  }, ms);
}

/* --------------------------- modal system --------------------------- */

const modalRoot = $('#modal-root');

function openModal(html, { wide = false, onMount = null } = {}) {
  const backdrop = document.createElement('div');
  backdrop.className = 'modal-backdrop';
  backdrop.innerHTML = `<div class="modal${wide ? ' wide' : ''}">${html}</div>`;
  modalRoot.appendChild(backdrop);
  const close = () => {
    const m = backdrop.firstElementChild;
    m.classList.add('modal-closing');
    backdrop.style.transition = 'opacity .16s ease';
    backdrop.style.opacity = '0';
    setTimeout(() => backdrop.remove(), 170);
    document.removeEventListener('keydown', onKey);
  };
  const onKey = (e) => { if (e.key === 'Escape') close(); };
  document.addEventListener('keydown', onKey);
  backdrop.addEventListener('mousedown', (e) => { if (e.target === backdrop) close(); });
  onMount?.(backdrop.firstElementChild, close);
  return close;
}

function confirmModal({ title = 'Are you sure?', body = '', confirmText = 'Confirm', danger = false }) {
  return new Promise((resolve) => {
    const close = openModal(`
      <div class="modal-head"><div class="modal-title">${esc(title)}</div></div>
      ${body ? `<p class="muted" style="margin-top:-6px;line-height:1.5">${esc(body)}</p>` : ''}
      <div class="row mt-4" style="justify-content:flex-end">
        <button class="btn btn-ghost" data-x="no">Cancel</button>
        <button class="btn ${danger ? 'btn-danger' : 'btn-primary'}" data-x="yes">${esc(confirmText)}</button>
      </div>`, {
      onMount(root, c) {
        $('[data-x="no"]', root).onclick = () => { c(); resolve(false); };
        $('[data-x="yes"]', root).onclick = () => { c(); resolve(true); };
      },
    });
    void close;
  });
}

/** Generic form modal. fields: [{key,label,type,value,placeholder,options,min,max}] */
function formModal({ title, fields = [], submitText = 'Save', danger = false, note = '' }) {
  return new Promise((resolve) => {
    const fieldHtml = fields.map((f) => {
      const val = f.value ?? '';
      if (f.type === 'select') {
        const opts = f.options.map((o) => `<option value="${esc(o.value)}" ${String(o.value) === String(val) ? 'selected' : ''}>${esc(o.label)}</option>`).join('');
        return `<div class="field"><label>${esc(f.label)}</label><select class="input" name="${esc(f.key)}">${opts}</select></div>`;
      }
      if (f.type === 'textarea') {
        return `<div class="field"><label>${esc(f.label)}</label><textarea class="input textarea" name="${esc(f.key)}" rows="3" placeholder="${esc(f.placeholder || '')}">${esc(val)}</textarea></div>`;
      }
      return `<div class="field"><label>${esc(f.label)}</label><input class="input" type="${f.type || 'text'}" name="${esc(f.key)}" value="${esc(val)}" placeholder="${esc(f.placeholder || '')}" ${f.min !== undefined ? `min="${f.min}"` : ''} ${f.max !== undefined ? `max="${f.max}"` : ''} /></div>`;
    }).join('');

    openModal(`
      <div class="modal-head"><div class="modal-title">${esc(title)}</div></div>
      ${note ? `<p class="muted small" style="margin-top:-8px">${esc(note)}</p>` : ''}
      <div class="form-error" data-err></div>
      ${fieldHtml}
      <div class="row mt-4" style="justify-content:flex-end">
        <button class="btn btn-ghost" data-x="cancel">Cancel</button>
        <button class="btn ${danger ? 'btn-danger' : 'btn-primary'}" data-x="ok">${esc(submitText)}</button>
      </div>`, {
      onMount(root, close) {
        $('[data-x="cancel"]', root).onclick = () => { close(); resolve(null); };
        $('[data-x="ok"]', root).onclick = () => {
          const out = {};
          for (const f of fields) {
            const el = root.querySelector(`[name="${CSS.escape(f.key)}"]`);
            out[f.key] = el ? el.value : '';
          }
          close(); resolve(out);
        };
        const first = root.querySelector('input,textarea,select');
        first?.focus();
      },
    });
  });
}

/* --------------------------- context menu --------------------------- */

let ctxClose = null;
function ctxMenu(x, y, items) {
  ctxClose?.();
  const menu = document.createElement('div');
  menu.className = 'ctx-menu';
  menu.innerHTML = items.map((it, i) => it.sep
    ? '<div class="ctx-sep"></div>'
    : `<button data-i="${i}" class="${it.danger ? 'danger' : ''}" ${it.disabled ? 'disabled' : ''}>${it.icon || ''}<span>${esc(it.label)}</span></button>`).join('');
  document.body.appendChild(menu);
  const r = menu.getBoundingClientRect();
  menu.style.left = `${Math.min(x, innerWidth - r.width - 10)}px`;
  menu.style.top = `${Math.min(y, innerHeight - r.height - 10)}px`;
  menu.addEventListener('click', (e) => {
    const b = e.target.closest('button[data-i]');
    if (!b || b.disabled) return;
    const it = items[Number(b.dataset.i)];
    close();
    it.onClick?.();
  });
  const close = () => { menu.remove(); document.removeEventListener('mousedown', onDoc); ctxClose = null; };
  const onDoc = (e) => { if (!menu.contains(e.target)) close(); };
  setTimeout(() => document.addEventListener('mousedown', onDoc), 0);
  ctxClose = close;
}

/* --------------------------- emoji picker --------------------------- */

const EMOJI = '😀😁😂🤣😊😍😘😎🤩🥳🤔🙄😅😭😢😡🤯🥺😴🤤🤗😈👋👍👎👏🙌🙏💪🔥✨💯🎉❤️🧡💛💚💙💜🤍💔✅❌⭐🌟☀️🌙🌈☕🍕🎮🎵💡🛡️🚀🐱🐶🦄🍀'.split(/(?=\p{Extended_Pictographic})/u).filter(Boolean);

function emojiPicker(anchor, onPick) {
  ctxClose?.();
  const pop = document.createElement('div');
  pop.className = 'emoji-pop';
  pop.innerHTML = `<div class="emoji-grid">${EMOJI.map((e) => `<button type="button">${e}</button>`).join('')}</div>`;
  document.body.appendChild(pop);
  const r = anchor.getBoundingClientRect();
  pop.style.left = `${Math.min(r.left, innerWidth - 310)}px`;
  pop.style.top = `${Math.max(10, r.top - pop.offsetHeight - 10)}px`;
  pop.addEventListener('click', (e) => {
    const b = e.target.closest('button');
    if (b) onPick(b.textContent);
  });
  const close = () => { pop.remove(); document.removeEventListener('mousedown', onDoc); };
  const onDoc = (e) => { if (!pop.contains(e.target) && !anchor.contains(e.target)) close(); };
  setTimeout(() => document.addEventListener('mousedown', onDoc), 0);
}

/* --------------------------- sound & title --------------------------- */

let audioCtx = null;
function blip() {
  if (!S.prefs.sound) return;
  try {
    audioCtx ||= new (window.AudioContext || window.webkitAudioContext)();
    const o = audioCtx.createOscillator();
    const g = audioCtx.createGain();
    o.connect(g); g.connect(audioCtx.destination);
    o.frequency.value = 740;
    g.gain.setValueAtTime(0.0001, audioCtx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.08, audioCtx.currentTime + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + 0.18);
    o.start(); o.stop(audioCtx.currentTime + 0.2);
  } catch { /* audio unavailable */ }
}

function updateTitle() {
  const total = S.chats.reduce((n, c) => n + (c.unread || 0), 0);
  document.title = total > 0 ? `(${total}) efadro` : 'efadro';
}

/* --------------------------- session storage --------------------------- */

const store = {
  get sessions() { try { return JSON.parse(localStorage.getItem('efadro:sessions') || '{}'); } catch { return {}; } },
  saveSession(base, data) {
    const s = store.sessions; s[base] = data;
    localStorage.setItem('efadro:sessions', JSON.stringify(s));
  },
  clearSession(base) {
    const s = store.sessions; delete s[base];
    localStorage.setItem('efadro:sessions', JSON.stringify(s));
  },
  get recentServers() { try { return JSON.parse(localStorage.getItem('efadro:servers') || '[]'); } catch { return []; } },
  addRecentServer(url, name) {
    let list = store.recentServers.filter((x) => x.url !== url);
    list.unshift({ url, name });
    localStorage.setItem('efadro:servers', JSON.stringify(list.slice(0, 5)));
  },
  get prefs() { try { return JSON.parse(localStorage.getItem('efadro:prefs') || '{}'); } catch { return {}; } },
  savePrefs(p) { localStorage.setItem('efadro:prefs', JSON.stringify(p)); },
};

/* ------------------------------- state ------------------------------- */

const S = {
  base: null,
  info: null,
  gateToken: null,
  token: null,
  user: null,
  ws: null,
  wsOpen: false,
  wsRetry: 0,
  wsManualClose: false,
  chats: [],
  activeChatId: null,
  msg: {},           // chatId -> { items: [], hasMore: bool }
  online: new Set(),
  typing: new Map(), // chatId -> Map(userId -> {user, timer})
  editing: null,     // message being edited
  prefs: { theme: 'dark', accent: '#6366f1', sound: true },
  tsToken: null,
  tsWidgetId: null,
  panel: { open: false, tab: 'users', cache: {} },
};

function applyPrefs() {
  document.documentElement.dataset.theme = S.prefs.theme;
  const accents = {
    '#6366f1': '#22d3ee', '#22d3ee': '#34d399', '#f472b6': '#a78bfa',
    '#fbbf24': '#f87171', '#34d399': '#22d3ee',
  };
  document.documentElement.style.setProperty('--accent', S.prefs.accent);
  document.documentElement.style.setProperty('--accent-2', accents[S.prefs.accent] || '#22d3ee');
}

/* ------------------------------- api -------------------------------- */

function normalizeBase(input) {
  let u = String(input || '').trim();
  if (!u) throw new Error('Enter a server address');
  if (!/^https?:\/\//i.test(u)) u = 'https://' + u;
  const url = new URL(u);
  return url.origin;
}

async function api(path, { method = 'GET', body, auth = true, gate = false } = {}) {
  const headers = {};
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  if (gate && S.gateToken) headers['Authorization'] = `Bearer ${S.gateToken}`;
  else if (auth && S.token) headers['Authorization'] = `Bearer ${S.token}`;
  let res;
  try {
    res = await fetch(S.base + path, { method, headers, body: body !== undefined ? JSON.stringify(body) : undefined });
  } catch {
    throw new Error('Cannot reach the server — check your connection');
  }
  let data = {};
  try { data = await res.json(); } catch { /* empty body */ }
  if (!res.ok) {
    const err = new Error(data.error || `Request failed (${res.status})`);
    err.status = res.status;
    err.data = data;
    if (res.status === 401 && data.code === 'auth' && auth) sessionExpired(data.error);
    throw err;
  }
  return data;
}

/* ------------------------------ turnstile ---------------------------- */

let tsScriptPromise = null;
function loadTurnstile() {
  if (window.turnstile) return Promise.resolve();
  tsScriptPromise ||= new Promise((resolve, reject) => {
    const s = document.createElement('script');
    s.src = 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit';
    s.async = true;
    s.defer = true;
    s.onload = () => resolve();
    s.onerror = () => reject(new Error('Failed to load captcha script'));
    document.head.appendChild(s);
  });
  return tsScriptPromise;
}

async function mountTurnstile(container) {
  S.tsToken = null;
  try { await loadTurnstile(); } catch (e) { throw e; }
  container.innerHTML = '';
  S.tsWidgetId = window.turnstile.render(container, {
    sitekey: S.info.turnstile.siteKey,
    theme: S.prefs.theme === 'light' ? 'light' : 'dark',
    callback: (token) => { S.tsToken = token; setErr('gate-err', ''); },
    'expired-callback': () => { S.tsToken = null; },
    'error-callback': () => { S.tsToken = null; setErr('gate-err', 'Captcha error — please retry'); },
  });
}
function resetTurnstile() {
  S.tsToken = null;
  try { if (S.tsWidgetId !== null && window.turnstile) window.turnstile.reset(S.tsWidgetId); } catch { /* ignore */ }
}

/* --------------------------- error helper --------------------------- */

function setErr(id, msg) {
  const el = document.getElementById(id);
  if (!el) return;
  el.textContent = msg || '';
  el.classList.toggle('show', Boolean(msg));
  if (msg) {
    el.classList.remove('show'); void el.offsetWidth; el.classList.add('show'); // restart shake
  }
}

/* ============================ JOIN FLOW ============================ */

function stepDots(active, total = 4) {
  return `<div class="gate-steps">${Array.from({ length: total }, (_, i) =>
    `<span class="${i < active ? 'done' : i === active ? 'active' : ''}"></span>`).join('')}</div>`;
}

const appRoot = $('#app');

function gateCardShell({ title, sub, step, body }) {
  return `
  <div class="center-stage">
    <div class="gate-card">
      <div class="gate-head"><div class="logo">e</div><div>
        <div class="gate-title">${esc(title)}</div>
      </div></div>
      <div class="gate-sub">${sub}</div>
      ${stepDots(step)}
      ${body}
    </div>
  </div>`;
}

function swapTo(renderFn) {
  const card = $('.gate-card');
  if (!card) return renderFn();
  card.classList.add('swap-out');
  setTimeout(renderFn, 210);
}

/* -------------------------- step 1: server -------------------------- */

function showServerScreen(notice = '') {
  teardownApp();
  const recent = store.recentServers;
  const defBase = localStorage.getItem('efadro:lastbase') ||
    (location.protocol.startsWith('http') ? location.origin : '');
  S.base = defBase || S.base;

  appRoot.innerHTML = gateCardShell({
    title: 'efadro',
    sub: 'Self-hosted messaging. Enter the address of the server you want to join.',
    step: 0,
    body: `
      ${notice ? `<div class="form-error show">${esc(notice)}</div>` : ''}
      <div class="form-error" id="gate-err"></div>
      <div class="field">
        <label>Server address</label>
        <input class="input mono" id="server-url" placeholder="https://chat.example.com" value="${esc(defBase)}" autocomplete="off" spellcheck="false" />
      </div>
      <button class="btn btn-primary btn-block mt-2" id="connect-btn">${icons.globe}<span>Connect</span></button>
      ${recent.length ? `<div class="small faint mt-4 mb-2">Recent servers</div>
        <div class="recent-servers">${recent.map((r) => `<button class="server-chip" data-url="${esc(r.url)}"><span class="dot"></span>${esc(r.name || r.url)}</button>`).join('')}</div>` : ''}
      <div class="small faint mt-4" style="text-align:center">Don't have a server? Ask an admin for an invite address.</div>
    `,
  });

  const input = $('#server-url');
  const btn = $('#connect-btn');
  input.focus();
  input.select();
  $$('.server-chip').forEach((chip) => chip.addEventListener('click', () => {
    input.value = chip.dataset.url;
    btn.click();
  }));
  const go = () => startFlow(input.value);
  btn.addEventListener('click', go);
  input.addEventListener('keydown', (e) => { if (e.key === 'Enter') go(); });
}

async function startFlow(baseInput, { skipIfSession = true } = {}) {
  setErr('gate-err', '');
  const btn = $('#connect-btn');
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner"></span><span>Connecting…</span>';
  try {
    S.base = normalizeBase(baseInput);
    S.info = null;
    const info = await (async () => {
      let res;
      try { res = await fetch(S.base + '/api/info'); } catch { throw new Error('Cannot reach that server. Check the address.'); }
      if (!res.ok) throw new Error('That address did not respond like an efadro server');
      const j = await res.json();
      if (j.product !== 'efadro') throw new Error('That address did not respond like an efadro server');
      return j;
    })();
    S.info = info;
    localStorage.setItem('efadro:lastbase', S.base);
    store.addRecentServer(S.base, info.name);

    // Quick-resume: a saved session for this server skips the whole gate.
    const sess = store.sessions[S.base];
    if (sess?.token && skipIfSession) {
      S.token = sess.token; S.user = sess.user;
      try {
        const me = await api('/api/auth/me');
        S.user = me.user;
        store.saveSession(S.base, { token: S.token, user: S.user });
        return enterApp();
      } catch (e) {
        store.clearSession(S.base);
        S.token = null; S.user = null;
        if (e?.data?.code === 'banned') return showServerScreen('Your account is banned on this server.');
      }
    }
    proceedToCaptcha();
  } catch (e) {
    btn.disabled = false;
    btn.innerHTML = `${icons.globe}<span>Connect</span>`;
    setErr('gate-err', e.message);
  }
}

/* ------------------------- step 2: captcha -------------------------- */

function proceedToCaptcha() {
  if (!S.info?.turnstile?.enabled) return proceedToPassword();
  swapTo(() => {
    appRoot.innerHTML = gateCardShell({
      title: 'Human check',
      sub: `<b>${esc(S.info.name)}</b> is protected by Cloudflare Turnstile. Complete the check to continue.`,
      step: 1,
      body: `
        <div class="form-error" id="gate-err"></div>
        <div id="ts-container"></div>
        <button class="btn btn-primary btn-block" id="ts-next" disabled><span>Continue</span></button>
        <div class="captcha-note">Protected by Cloudflare Turnstile</div>
        <div class="row mt-3" style="justify-content:space-between">
          <button class="link" id="back-server">← different server</button>
          <span class="server-chip"><span class="dot"></span>${esc(S.info.name)}</span>
        </div>`,
    });
    mountTurnstile($('#ts-container')).catch(() => setErr('gate-err', 'Failed to load captcha — check your network'));
    $('#back-server').onclick = () => showServerScreen();
    const next = $('#ts-next');
    const poll = setInterval(() => {
      if (!document.body.contains(next)) return clearInterval(poll);
      next.disabled = !S.tsToken;
    }, 250);
    next.onclick = () => { clearInterval(poll); proceedToPassword(); };
  });
}

/* ----------------------- step 3: server password ----------------------- */

function proceedToPassword() {
  if (!S.info?.serverPasswordRequired) return submitGate('');
  swapTo(() => {
    appRoot.innerHTML = gateCardShell({
      title: 'Server password',
      sub: `<b>${esc(S.info.name)}</b> requires a password to join. Ask the server admin if you don't have it.`,
      step: 2,
      body: `
        <div class="form-error" id="gate-err"></div>
        <div class="field">
          <label>Server password</label>
          <div class="input-wrap">
            <input class="input" id="server-pass" type="password" placeholder="••••••••" autocomplete="off" />
            <button class="input-eye" id="toggle-pass" type="button">${icons.eye}</button>
          </div>
        </div>
        <button class="btn btn-primary btn-block mt-2" id="pass-next">${icons.lock}<span>Unlock server</span></button>
        <div class="row mt-3"><button class="link" id="back-cap">← back</button></div>`,
    });
    const input = $('#server-pass');
    input.focus();
    $('#toggle-pass').onclick = (e) => {
      input.type = input.type === 'password' ? 'text' : 'password';
      e.currentTarget.innerHTML = input.type === 'password' ? icons.eye : icons.eyeOff;
    };
    const go = () => submitGate(input.value);
    $('#pass-next').onclick = go;
    input.addEventListener('keydown', (e) => { if (e.key === 'Enter') go(); });
    $('#back-cap').onclick = () => (S.info.turnstile.enabled ? (resetTurnstile(), proceedToCaptcha()) : showServerScreen());
  });
}

async function submitGate(serverPassword) {
  setErr('gate-err', '');
  const btn = $('#pass-next') || $('#ts-next');
  if (btn) { btn.disabled = true; btn.innerHTML = '<span class="spinner"></span><span>Verifying…</span>'; }
  try {
    const j = await api('/api/gate', {
      method: 'POST', auth: false,
      body: { serverPassword, turnstileToken: S.tsToken || '' },
    });
    S.gateToken = j.gateToken;
    showAuth('login');
  } catch (e) {
    if (e?.data?.code === 'captcha' && S.info.turnstile.enabled) {
      resetTurnstile();
      return proceedToCaptcha(), setTimeout(() => setErr('gate-err', e.message), 260);
    }
    if (btn) { btn.disabled = false; btn.innerHTML = `${icons.lock}<span>Unlock server</span>`; }
    setErr('gate-err', e.message);
  }
}

/* ------------------------- step 4: login/signup ------------------------- */

function showAuth(mode = 'login', prefill = {}) {
  const regOn = S.info?.registrationEnabled;
  swapTo(() => {
    appRoot.innerHTML = gateCardShell({
      title: mode === 'login' ? 'Welcome back' : 'Create account',
      sub: `Signing in to <b>${esc(S.info.name)}</b>`,
      step: 3,
      body: `
        ${regOn ? `
        <div class="auth-tabs">
          <div class="tab-pill ${mode === 'register' ? 'right' : ''}"></div>
          <button class="${mode === 'login' ? 'active' : ''}" id="tab-login">Sign in</button>
          <button class="${mode === 'register' ? 'active' : ''}" id="tab-register">Sign up</button>
        </div>` : `<div class="small muted mb-3">Registration is closed on this server — sign in with an existing account.</div>`}
        <div class="form-error" id="gate-err"></div>
        ${mode === 'register' ? `
        <div class="field"><label>Display name</label>
          <input class="input" id="auth-display" maxlength="40" placeholder="How others will see you" value="${esc(prefill.displayName || '')}" /></div>` : ''}
        <div class="field"><label>Username</label>
          <input class="input mono" id="auth-user" maxlength="24" placeholder="username" value="${esc(prefill.username || '')}" autocomplete="username" spellcheck="false" /></div>
        <div class="field"><label>Password ${mode === 'register' ? '<span class="faint">(min. 8 chars)</span>' : ''}</label>
          <div class="input-wrap">
            <input class="input" id="auth-pass" type="password" placeholder="••••••••" autocomplete="${mode === 'register' ? 'new-password' : 'current-password'}" />
            <button class="input-eye" id="toggle-auth-pass" type="button">${icons.eye}</button>
          </div></div>
        <button class="btn btn-primary btn-block mt-2" id="auth-go">${mode === 'login' ? 'Sign in' : 'Create account'}</button>
        <div class="row mt-3" style="justify-content:space-between">
          <button class="link" id="auth-back">← start over</button>
          <span class="server-chip"><span class="dot"></span>${esc(S.info.name)}</span>
        </div>`,
    });

    $('#tab-login')?.addEventListener('click', () => showAuth('login', collectAuth()));
    $('#tab-register')?.addEventListener('click', () => showAuth('register', collectAuth()));
    $('#auth-back').onclick = () => showServerScreen();
    const passEl = $('#auth-pass');
    $('#toggle-auth-pass').onclick = (e) => {
      passEl.type = passEl.type === 'password' ? 'text' : 'password';
      e.currentTarget.innerHTML = passEl.type === 'password' ? icons.eye : icons.eyeOff;
    };
    const userEl = $('#auth-user');
    (prefill.username ? passEl : userEl).focus();
    const submit = () => doAuth(mode);
    $('#auth-go').onclick = submit;
    [userEl, passEl, $('#auth-display')].forEach((el) => el?.addEventListener('keydown', (e) => { if (e.key === 'Enter') submit(); }));
  });
}

function collectAuth() {
  return {
    username: $('#auth-user')?.value || '',
    displayName: $('#auth-display')?.value || '',
  };
}

async function doAuth(mode) {
  setErr('gate-err', '');
  const btn = $('#auth-go');
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner"></span><span>One moment…</span>';
  try {
    const username = $('#auth-user').value.trim();
    const password = $('#auth-pass').value;
    const body = mode === 'register'
      ? { username, password, displayName: $('#auth-display')?.value.trim() }
      : { username, password };
    const j = await api(`/api/auth/${mode === 'register' ? 'signup' : 'login'}`, {
      method: 'POST', body, auth: false, gate: true,
    });
    S.token = j.token;
    S.user = j.user;
    store.saveSession(S.base, { token: S.token, user: S.user });
    toast(`Welcome, ${j.user.displayName}!`, 'success');
    enterApp();
  } catch (e) {
    btn.disabled = false;
    btn.textContent = mode === 'register' ? 'Create account' : 'Sign in';
    if (e?.data?.code === 'gate') {
      // gate token expired — silently get a fresh one when possible
      if (!S.info.serverPasswordRequired && !S.info.turnstile.enabled) {
        try {
          const g = await api('/api/gate', { method: 'POST', auth: false, body: {} });
          S.gateToken = g.gateToken;
          return doAuth(mode);
        } catch { /* fall through */ }
      }
      return showServerScreen('Your join window expired — please join again.');
    }
    setErr('gate-err', e.message);
  }
}

/* ============================== CHAT APP ============================== */

function avatarHtml(user, sizeClass = '', withPresence = false, group = false) {
  const bg = user?.avatarColor || '#6366f1';
  const content = user?.selfChat ? '🔖' : esc(initials(user?.displayName || user?.name));
  return `<div class="avatar ${sizeClass} ${group ? 'group' : ''}" style="background:${esc(bg)}">${content}
    ${withPresence ? `<span class="presence ${S.online.has(user?.id) ? 'on' : ''}" data-pid="${esc(user?.id || '')}"></span>` : ''}
  </div>`;
}

const roleBadge = (role) => `<span class="role-badge role-${esc(role)}">${esc(role)}</span>`;

function chatTitle(chat) {
  if (chat.type === 'group') return chat.name || 'Group';
  const other = chat.members.find((m) => m.id !== S.user.id);
  return other ? other.displayName : 'Saved Messages';
}
function chatPeer(chat) {
  return chat.members.find((m) => m.id !== S.user.id) || null;
}
function chatAvatar(chat, sizeClass = '', withPresence = true) {
  if (chat.type === 'group') return avatarHtml({ displayName: chat.name, avatarColor: '#4f46e5' }, sizeClass, false, true);
  const other = chatPeer(chat);
  if (!other) return avatarHtml({ selfChat: true, avatarColor: '#0ea5e9' }, sizeClass);
  return avatarHtml(other, sizeClass, withPresence);
}

function teardownApp() {
  S.wsManualClose = true;
  try { S.ws?.close(); } catch { /* ignore */ }
  S.ws = null; S.wsOpen = false;
  S.chats = [];
  S.activeChatId = null;
  S.msg = {};
  S.online = new Set();
  S.typing = new Map();
  S.editing = null;
  S.panel = { open: false, tab: 'users', cache: {} };
  document.title = 'efadro';
}

function sessionExpired(reason) {
  if (!S.base) return;
  store.clearSession(S.base);
  S.token = null; S.user = null;
  if ($('.shell') || $('.panel-overlay')) {
    showServerScreen(reason || 'Session expired — please sign in again.');
  }
}

async function logout() {
  teardownApp();
  store.clearSession(S.base);
  S.token = null; S.user = null; S.gateToken = null;
  showServerScreen();
}

async function enterApp() {
  renderShell();
  await loadChats();
  connectWS();
}

function renderShell() {
  const isStaff = roleLevel(S.user.role) >= 1;
  appRoot.innerHTML = `
  <div class="shell" id="shell">
    <aside class="sidebar">
      <div class="side-top">
        <div class="logo logo-sm">e</div>
        <div class="titles grow">
          <div class="t1">${esc(S.info?.name || 'efadro')}</div>
          <div class="t2"><span class="conn-dot" id="conn-dot"></span><span id="conn-text">connecting…</span></div>
        </div>
      </div>
      <div class="side-actions">
        <div class="search-box">${icons.search}<input class="input" id="chat-filter" placeholder="Search chats" /></div>
        <button class="btn btn-icon" id="new-chat-btn" title="New chat">${icons.plus}</button>
      </div>
      <div class="chat-list" id="chat-list"></div>
      <div class="side-bottom">
        <div class="user-chip" id="me-chip">
          ${avatarHtml(S.user, 'sm')}
          <div class="grow" style="min-width:0">
            <div class="uc-name">${esc(S.user.displayName)}</div>
            <div class="uc-role">${esc(S.user.role)}</div>
          </div>
        </div>
        ${isStaff ? `<button class="btn btn-icon" id="panel-btn" title="Staff panel">${icons.shield}</button>` : ''}
        <button class="btn btn-icon" id="settings-btn" title="Settings">${icons.gear}</button>
        <button class="btn btn-icon" id="logout-btn" title="Sign out">${icons.logout}</button>
      </div>
    </aside>
    <main class="chat-pane" id="chat-pane">
      <div class="chat-empty">
        <div class="big-icon">${icons.chat}</div>
        <div>Select a chat to start messaging</div>
        <button class="btn btn-primary btn-sm" id="empty-new-chat">${icons.plus}<span>New chat</span></button>
      </div>
    </main>
  </div>`;

  $('#logout-btn').onclick = async () => { if (await confirmModal({ title: 'Sign out?', confirmText: 'Sign out' })) logout(); };
  $('#settings-btn').onclick = openSettings;
  $('#panel-btn')?.addEventListener('click', () => openPanel());
  $('#me-chip').onclick = openSettings;
  $('#new-chat-btn').onclick = openNewChat;
  $('#empty-new-chat')?.addEventListener('click', openNewChat);
  $('#chat-filter').addEventListener('input', (e) => renderChatList(e.target.value));
  renderChatList();
  setConn('wait', 'connecting…');
}

function setConn(state, text) {
  const dot = $('#conn-dot'), t = $('#conn-text');
  if (!dot || !t) return;
  dot.className = `conn-dot ${state === 'on' ? 'on' : state === 'wait' ? 'wait' : ''}`;
  t.textContent = text;
}

/* ------------------------------ chat list ------------------------------ */

async function loadChats() {
  const list = $('#chat-list');
  list.innerHTML = Array.from({ length: 4 }, () => `
    <div class="sk-item"><div class="sk sk-circle"></div>
      <div class="sk-lines"><div class="sk sk-line w60"></div><div class="sk sk-line w85"></div></div>
    </div>`).join('');
  try {
    const { chats } = await api('/api/chats');
    S.chats = chats;
    sortChats();
    renderChatList();
  } catch (e) {
    list.innerHTML = `<div class="empty-note">${esc(e.message)}</div>`;
  }
}

function sortChats() {
  S.chats.sort((a, b) => ((b.lastMessage?.createdAt ?? b.createdAt) - (a.lastMessage?.createdAt ?? a.createdAt)));
}

function upsertChat(chat) {
  const i = S.chats.findIndex((c) => c.id === chat.id);
  if (i >= 0) S.chats[i] = chat; else S.chats.unshift(chat);
  sortChats();
}

const getChat = (id) => S.chats.find((c) => c.id === id);

function renderChatList(filter = '') {
  const list = $('#chat-list');
  if (!list) return;
  const q = filter.trim().toLowerCase();
  const chats = S.chats.filter((c) => !q || chatTitle(c).toLowerCase().includes(q));
  if (!chats.length) {
    list.innerHTML = `<div class="empty-note">${q ? 'No chats match your search' : 'No chats yet — press + to start one'}</div>`;
    return;
  }
  list.innerHTML = `<div class="list-label">Chats</div>` + chats.map((c) => {
    const lm = c.lastMessage;
    const author = lm ? (lm.author.id === S.user.id ? 'You' : (c.type === 'group' ? lm.author.displayName : '')) : '';
    const preview = lm ? `${author ? author + ': ' : ''}${lm.content}` : 'No messages yet';
    const time = lm ? fmtListTime(lm.createdAt) : '';
    return `
    <div class="chat-item ${c.id === S.activeChatId ? 'active' : ''}" data-chat-id="${esc(c.id)}">
      ${chatAvatar(c, '', true)}
      <div class="ci-main">
        <div class="ci-title"><span class="ci-name">${esc(chatTitle(c))}</span><span class="ci-time">${esc(time)}</span></div>
        <div class="ci-preview">${esc(preview)}</div>
      </div>
      ${c.unread > 0 ? `<span class="ci-badge">${c.unread > 99 ? '99+' : c.unread}</span>` : ''}
    </div>`;
  }).join('');
  updateTitle();
}

/* --------------------------- open / render chat --------------------------- */

async function openChat(chatId) {
  const chat = getChat(chatId);
  if (!chat) return;
  S.activeChatId = chatId;
  S.editing = null;
  $('#shell')?.classList.add('chat-open');
  renderChatList($('#chat-filter')?.value || '');
  renderChatPane(chat);
  if (!S.msg[chatId]) {
    $('#messages').innerHTML = `<div class="empty-note"><span class="spinner"></span></div>`;
    await loadMessages(chatId, true);
  } else {
    renderMessages(chatId);
  }
  markRead(chatId);
  const ta = $('#composer-input');
  ta?.focus();
}

function closeChat() {
  S.activeChatId = null;
  $('#shell')?.classList.remove('chat-open');
  renderChatList($('#chat-filter')?.value || '');
  $('#chat-pane').innerHTML = `
    <div class="chat-empty">
      <div class="big-icon">${icons.chat}</div>
      <div>Select a chat to start messaging</div>
    </div>`;
}

function renderChatPane(chat) {
  const pane = $('#chat-pane');
  const peer = chatPeer(chat);
  const sub = chat.type === 'group'
    ? `${chat.members.length} member${chat.members.length === 1 ? '' : 's'}`
    : peer
      ? (S.online.has(peer.id) ? '<span class="accent">online</span>' : esc(fmtLastSeen(peer.lastSeen)))
      : 'notes to yourself';

  pane.innerHTML = `
    <div class="chat-header">
      <button class="btn btn-icon back-btn" id="chat-back">${icons.back}</button>
      ${chatAvatar(chat, 'sm')}
      <div class="grow" style="min-width:0;cursor:pointer" id="chat-info-btn">
        <div class="ch-title">${esc(chatTitle(chat))}</div>
        <div class="ch-sub" id="chat-sub">${sub}</div>
      </div>
      <button class="btn btn-icon" id="members-btn" title="Members">${chat.type === 'group' ? icons.users : icons.user}</button>
    </div>
    <div class="messages" id="messages"></div>
    <div class="typing-bar">
      <span id="typing-area"></span>
      <span class="read-status grow" id="read-status"></span>
    </div>
    <div id="mute-area"></div>
    <div class="composer" id="composer-wrap">
      <div id="edit-banner"></div>
      <div class="composer-inner">
        <button class="btn btn-ghost btn-icon tool-btn" id="emoji-btn" title="Emoji">${icons.smile}</button>
        <textarea id="composer-input" rows="1" placeholder="Message" maxlength="${S.info?.limits?.maxMessageLength || 4000}"></textarea>
        <button class="btn btn-primary btn-icon send-btn" id="send-btn" title="Send">${icons.send}</button>
      </div>
    </div>
    <button class="scroll-bottom-btn" id="scroll-bottom">${icons.down}</button>`;

  $('#chat-back').onclick = closeChat;
  $('#members-btn').onclick = () => openMembersDrawer(chat.id);
  $('#chat-info-btn').onclick = () => openMembersDrawer(chat.id);
  $('#scroll-bottom').onclick = () => scrollMessages(true);

  const ta = $('#composer-input');
  ta.addEventListener('input', () => {
    ta.style.height = 'auto';
    ta.style.height = Math.min(160, ta.scrollHeight) + 'px';
    sendTyping();
  });
  ta.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendCurrentMessage();
    }
  });
  $('#send-btn').onclick = sendCurrentMessage;
  $('#emoji-btn').onclick = (e) => emojiPicker(e.currentTarget, (emo) => {
    const start = ta.selectionStart ?? ta.value.length;
    ta.value = ta.value.slice(0, start) + emo + ta.value.slice(ta.selectionEnd ?? start);
    ta.focus();
    ta.selectionStart = ta.selectionEnd = start + emo.length;
  });

  const msgs = $('#messages');
  msgs.addEventListener('scroll', () => {
    const nearBottom = msgs.scrollHeight - msgs.scrollTop - msgs.clientHeight < 220;
    $('#scroll-bottom').classList.toggle('show', !nearBottom);
    if (msgs.scrollTop < 80) loadOlderMessages(chat.id);
    if (nearBottom) markReadSoon(chat.id);
  });

  renderMuteBanner();
}

function renderMuteBanner() {
  const area = $('#mute-area');
  const wrap = $('#composer-wrap');
  if (!area || !wrap) return;
  const muted = (S.user.mutedUntil || 0) > Date.now();
  area.innerHTML = muted
    ? `<div class="mute-banner">${icons.warn}<span>You are muted until <b>${new Date(S.user.mutedUntil).toLocaleString()}</b>${S.user.muteReason ? ` — ${esc(S.user.muteReason)}` : ''}</span></div>`
    : '';
  wrap.style.display = muted ? 'none' : '';
}

/* ----------------------------- messages ------------------------------ */

async function loadMessages(chatId, initial = false) {
  const st = (S.msg[chatId] ||= { items: [], hasMore: true, loadingOlder: false });
  try {
    const { messages, hasMore } = await api(`/api/chats/${encodeURIComponent(chatId)}/messages?limit=40`);
    st.items = messages;
    st.hasMore = hasMore;
    if (initial || S.activeChatId === chatId) renderMessages(chatId);
  } catch (e) {
    if (S.activeChatId === chatId) $('#messages').innerHTML = `<div class="empty-note">${esc(e.message)}</div>`;
  }
}

async function loadOlderMessages(chatId) {
  const st = S.msg[chatId];
  if (!st || !st.hasMore || st.loadingOlder || !st.items.length) return;
  st.loadingOlder = true;
  const box = $('#messages');
  const prevHeight = box ? box.scrollHeight : 0;
  try {
    const before = st.items[0].id;
    const { messages, hasMore } = await api(`/api/chats/${encodeURIComponent(chatId)}/messages?limit=40&before=${before}`);
    st.items = [...messages, ...st.items];
    st.hasMore = hasMore;
    if (S.activeChatId === chatId) {
      renderMessages(chatId, { keepScroll: true });
      if (box) box.scrollTop = box.scrollHeight - prevHeight;
    }
  } catch { /* keep state, retry on next scroll */ }
  st.loadingOlder = false;
}

function roleColor(role) {
  return { owner: 'var(--warning)', admin: 'var(--danger)', moderator: 'var(--info)' }[role] || 'var(--accent-2)';
}

const URL_RE = /(https?:\/\/[^\s"'<>()]+)/g;
function renderContent(raw) {
  let out = '';
  let last = 0;
  let m;
  URL_RE.lastIndex = 0;
  while ((m = URL_RE.exec(raw))) {
    out += esc(raw.slice(last, m.index));
    let u = m[0];
    const trail = (u.match(/[.,;:!?)\]]+$/) || [''])[0];
    u = u.slice(0, u.length - trail.length);
    const safe = esc(u);
    if (/\.(png|jpe?g|gif|webp|avif)(\?[^\s]*)?$/i.test(u)) {
      out += `<a href="${safe}" target="_blank" rel="noopener noreferrer">${safe}</a><br><img class="msg-img" loading="lazy" src="${safe}" alt="image" />`;
    } else {
      out += `<a href="${safe}" target="_blank" rel="noopener noreferrer">${safe}</a>`;
    }
    out += esc(trail);
    last = m.index + m[0].length;
  }
  out += esc(raw.slice(last));
  return out;
}

function shouldGroup(prev, cur) {
  return prev && prev.author.id === cur.author.id && (cur.createdAt - prev.createdAt) < 5 * 60000;
}

function messageNode(msg, prevMsg) {
  const own = msg.author.id === S.user.id;
  const grouped = shouldGroup(prevMsg, msg);
  const row = document.createElement('div');
  row.className = `msg-row ${own ? 'out' : ''} ${grouped ? 'grouped' : ''}`;
  row.dataset.msgId = msg.id;
  row.dataset.authorId = msg.author.id;
  row.dataset.ts = msg.createdAt;
  const canDelete = own || roleLevel(S.user.role) > roleLevel(msg.author.role) || (getChat(msg.chatId)?.createdBy === S.user.id && getChat(msg.chatId)?.type === 'group');
  const canEdit = own;
  row.innerHTML = `
    ${avatarHtml(msg.author, 'xs')}
    <div class="msg-bubble">
      <div class="msg-head">
        <span class="msg-author" style="color:${own ? 'rgba(255,255,255,.85)' : roleColor(msg.author.role)}">${esc(msg.author.displayName)}</span>
        <span class="msg-time">${fmtTime(msg.createdAt)}</span>
      </div>
      <div class="msg-text">${renderContent(msg.content)}${msg.editedAt ? '<span class="msg-edited">(edited)</span>' : ''}</div>
      <div class="msg-actions">
        ${canEdit ? `<button data-act="edit" title="Edit">${icons.pencil}</button>` : ''}
        <button data-act="copy" title="Copy">${icons.copy}</button>
        ${!own ? `<button data-act="report" title="Report">${icons.flag}</button>` : ''}
        ${canDelete ? `<button data-act="del" class="danger" title="Delete">${icons.trash}</button>` : ''}
      </div>
    </div>`;
  return row;
}

function renderMessages(chatId, { keepScroll = false } = {}) {
  const box = $('#messages');
  const st = S.msg[chatId];
  if (!box || !st) return;
  const wasNearBottom = box.scrollHeight - box.scrollTop - box.clientHeight < 250;
  box.innerHTML = '';
  if (st.hasMore && st.items.length) {
    const more = document.createElement('div');
    more.className = 'empty-note';
    more.textContent = 'Scroll up to load older messages';
    box.appendChild(more);
  }
  let prev = null;
  let lastDay = '';
  for (const m of st.items) {
    const day = fmtDay(m.createdAt);
    if (day !== lastDay) {
      lastDay = day;
      const d = document.createElement('div');
      d.className = 'day-sep';
      d.textContent = day;
      box.appendChild(d);
      prev = null;
    }
    box.appendChild(messageNode(m, prev));
    prev = m;
  }
  if (!st.items.length) {
    const e = document.createElement('div');
    e.className = 'empty-note';
    e.textContent = 'No messages yet — say hi! 👋';
    box.appendChild(e);
  }
  if (!keepScroll && wasNearBottom) scrollMessages(true);
  updateReadStatus();
}

function scrollMessages(instant = false) {
  const box = $('#messages');
  if (!box) return;
  if (instant) box.style.scrollBehavior = 'auto';
  box.scrollTop = box.scrollHeight;
  if (instant) box.style.scrollBehavior = '';
}

function appendMessageNode(msg) {
  const box = $('#messages');
  const st = S.msg[msg.chatId];
  if (!box || !st || S.activeChatId !== msg.chatId) return;
  const prev = st.items[st.items.length - 1] || null;
  const day = fmtDay(msg.createdAt);
  const lastSep = $$('.day-sep', box).pop();
  if (!lastSep || lastSep.textContent !== day) {
    const d = document.createElement('div');
    d.className = 'day-sep';
    d.textContent = day;
    box.appendChild(d);
    prev && (prev._groupBreak = true);
  }
  const empty = $('.empty-note', box);
  empty?.remove();
  box.appendChild(messageNode(msg, prev && !prev._groupBreak ? prev : null));
  const nearBottom = box.scrollHeight - box.scrollTop - box.clientHeight < 250;
  if (nearBottom || msg.author.id === S.user.id) scrollMessages();
  else $('#scroll-bottom')?.classList.add('show');
}

/* --------------------------- read receipts --------------------------- */

const readThrottle = new Map();
function markReadSoon(chatId) {
  if (readThrottle.has(chatId)) return;
  readThrottle.set(chatId, setTimeout(() => { readThrottle.delete(chatId); markRead(chatId); }, 600));
}

function markRead(chatId) {
  const chat = getChat(chatId);
  const st = S.msg[chatId];
  const last = st?.items?.[st.items.length - 1];
  if (!chat || !last) { if (chat) { chat.unread = 0; renderChatList($('#chat-filter')?.value || ''); } return; }
  if (chat.unread === 0 && chat.myLastRead >= last.id) return;
  chat.unread = 0;
  chat.myLastRead = last.id;
  renderChatList($('#chat-filter')?.value || '');
  wsSend({ t: 'read', data: { chatId, messageId: last.id } }) ||
    api(`/api/chats/${encodeURIComponent(chatId)}/read`, { method: 'POST', body: { messageId: last.id } }).catch(() => {});
}

function updateReadStatus() {
  const el = $('#read-status');
  if (!el) return;
  const chat = getChat(S.activeChatId);
  if (!chat || chat.type !== 'dm') { el.innerHTML = ''; return; }
  const peer = chatPeer(chat);
  if (!peer) { el.innerHTML = ''; return; } // saved messages
  const st = S.msg[chat.id];
  const lastOwn = st?.items ? [...st.items].reverse().find((m) => m.author.id === S.user.id) : null;
  if (!lastOwn) { el.innerHTML = ''; return; }
  const peerMember = chat.members.find((m) => m.id === peer.id);
  const seen = (peerMember?.lastRead || 0) >= lastOwn.id;
  el.innerHTML = seen
    ? `<span class="seen">${icons.checks} Seen</span>`
    : `${icons.check} Sent`;
}

/* ----------------------------- composer ------------------------------ */

let typingSentAt = 0;

function sendTyping() {
  if (!S.activeChatId) return;
  const t = Date.now();
  if (t - typingSentAt < 1800) return;
  typingSentAt = t;
  wsSend({ t: 'typing', data: { chatId: S.activeChatId, typing: true } });
}

async function sendCurrentMessage() {
  const ta = $('#composer-input');
  if (!ta || !S.activeChatId) return;
  const content = ta.value.trim();
  if (!content) return;

  // Editing existing message
  if (S.editing) {
    const editing = S.editing;
    cancelEdit();
    try {
      await api(`/api/messages/${editing.id}`, { method: 'PATCH', body: { content } });
    } catch (e) { toast(e.message, 'error'); }
    return;
  }

  ta.value = '';
  ta.style.height = 'auto';
  ta.focus();
  const chatId = S.activeChatId;
  const clientId = 'c' + Date.now() + Math.random().toString(36).slice(2, 7);

  // Optimistic bubble
  const st = (S.msg[chatId] ||= { items: [], hasMore: false });
  const tempMsg = {
    id: clientId, chatId, content, createdAt: Date.now(), editedAt: null,
    author: { ...S.user },
  };
  st.items.push(tempMsg);
  appendMessageNode(tempMsg);
  const chat = getChat(chatId);
  if (chat) {
    chat.lastMessage = tempMsg;
    sortChats();
    renderChatList($('#chat-filter')?.value || '');
  }

  const sent = wsSend({ t: 'msg:send', data: { chatId, content, clientId } });
  if (!sent) {
    try {
      await api(`/api/chats/${encodeURIComponent(chatId)}/messages`, { method: 'POST', body: { content, clientId } });
    } catch (e) {
      toast(e.message, 'error');
    }
  }
}

function startEdit(msg) {
  S.editing = msg;
  const banner = $('#edit-banner');
  const ta = $('#composer-input');
  banner.innerHTML = `
    <div class="mute-banner" style="background:color-mix(in srgb, var(--info) 10%, transparent);border-color:color-mix(in srgb, var(--info) 28%, transparent);color:var(--info)">
      ${icons.pencil}<span class="grow">Editing message</span>
      <button class="btn btn-ghost btn-sm" id="cancel-edit">Cancel</button>
    </div>`;
  ta.value = msg.content;
  ta.focus();
  ta.selectionStart = ta.selectionEnd = ta.value.length;
  $('#cancel-edit').onclick = cancelEdit;
}

function cancelEdit() {
  S.editing = null;
  const ta = $('#composer-input');
  if (ta) { ta.value = ''; ta.style.height = 'auto'; }
  const b = $('#edit-banner');
  if (b) b.innerHTML = '';
}

/* ------------------------- message item actions ------------------------- */

document.addEventListener('click', async (e) => {
  const actBtn = e.target.closest('.msg-actions button');
  if (!actBtn) return;
  const row = actBtn.closest('.msg-row');
  const msgId = row?.dataset.msgId;
  const chat = getChat(S.activeChatId);
  const st = chat && S.msg[chat.id];
  const msg = st?.items.find((m) => String(m.id) === String(msgId));
  if (!msg) return;
  const act = actBtn.dataset.act;
  if (act === 'copy') {
    try { await navigator.clipboard.writeText(msg.content); toast('Copied to clipboard', 'success', 1500); } catch { toast('Copy failed', 'error'); }
  } else if (act === 'edit') {
    startEdit(msg);
  } else if (act === 'del') {
    if (await confirmModal({ title: 'Delete message?', body: 'This cannot be undone.', confirmText: 'Delete', danger: true })) {
      try { await api(`/api/messages/${msg.id}`, { method: 'DELETE' }); } catch (err) { toast(err.message, 'error'); }
    }
  } else if (act === 'report') {
    const vals = await formModal({
      title: 'Report message',
      note: 'Moderators will review this report.',
      fields: [{ key: 'reason', label: 'Reason', type: 'textarea', placeholder: 'What is wrong with this message?' }],
      submitText: 'Send report',
    });
    if (vals) {
      try {
        await api(`/api/messages/${msg.id}/report`, { method: 'POST', body: { reason: vals.reason } });
        toast('Report sent to moderators', 'success');
      } catch (err) { toast(err.message, 'error'); }
    }
  }
});

/* ------------------------------ websocket ------------------------------ */

function connectWS() {
  if (S.ws) { try { S.ws.close(); } catch { /* ignore */ } }
  S.wsManualClose = false;
  const url = S.base.replace(/^http/, 'ws') + '/ws?token=' + encodeURIComponent(S.token);
  setConn('wait', 'connecting…');
  const ws = new WebSocket(url);
  S.ws = ws;

  ws.onopen = () => {
    S.wsOpen = true;
    S.wsRetry = 0;
    setConn('on', 'connected');
  };

  ws.onmessage = (ev) => {
    let frame;
    try { frame = JSON.parse(ev.data); } catch { return; }
    handleWsEvent(frame);
  };

  ws.onclose = (ev) => {
    S.wsOpen = false;
    if (S.wsManualClose) return;
    setConn('', 'offline — reconnecting…');
    if (ev.code === 4001) return; // force_logout handled separately
    const delay = Math.min(15000, 900 * Math.pow(2, S.wsRetry++));
    setTimeout(() => { if (!S.wsManualClose && S.token) connectWS(); }, delay);
  };

  ws.onerror = () => { /* onclose follows */ };
}

function wsSend(obj) {
  if (S.ws && S.wsOpen && S.ws.readyState === WebSocket.OPEN) {
    try { S.ws.send(JSON.stringify(obj)); return true; } catch { return false; }
  }
  return false;
}

function handleWsEvent({ t, data = {} }) {
  switch (t) {
    case 'ready': {
      S.user = { ...S.user, ...data.user };
      S.online = new Set(data.online || []);
      store.saveSession(S.base, { token: S.token, user: S.user });
      renderMuteBanner();
      refreshPresenceDots();
      break;
    }

    case 'msg:new': {
      const { message, clientId } = data;
      // Replace optimistic echo
      const st = (S.msg[message.chatId] ||= { items: [], hasMore: true });
      const tempIdx = clientId ? st.items.findIndex((m) => String(m.id) === String(clientId)) : -1;
      if (tempIdx >= 0) {
        st.items[tempIdx] = message;
        const row = $(`.msg-row[data-msg-id="${CSS.escape(String(clientId))}"]`);
        if (row) {
          row.dataset.msgId = message.id;
          const text = $('.msg-text', row);
          if (text) text.innerHTML = renderContent(message.content);
        }
      } else if (!st.items.some((m) => m.id === message.id)) {
        st.items.push(message);
        appendMessageNode(message);
      }
      const chat = getChat(message.chatId);
      if (chat) {
        chat.lastMessage = message;
        const own = message.author.id === S.user.id;
        const isActive = S.activeChatId === chat.id && document.hasFocus();
        if (!own) {
          if (isActive) markReadSoon(chat.id);
          else chat.unread = (chat.unread || 0) + 1;
        }
        sortChats();
        renderChatList($('#chat-filter')?.value || '');
        if (!own && (!isActive)) { blip(); }
      } else {
        // Message in a chat we don't know (fresh) — refresh list
        api(`/api/chats/${encodeURIComponent(message.chatId)}`).then(({ chat: c }) => {
          upsertChat(c);
          renderChatList($('#chat-filter')?.value || '');
        }).catch(() => {});
      }
      // clear typing indicator for that author
      const tm = S.typing.get(message.chatId);
      if (tm?.has(message.author.id)) {
        clearTimeout(tm.get(message.author.id).timer);
        tm.delete(message.author.id);
        renderTypingBar();
      }
      updateReadStatus();
      break;
    }

    case 'msg:edited': {
      const { message } = data;
      const st = S.msg[message.chatId];
      const i = st?.items.findIndex((m) => m.id === message.id) ?? -1;
      if (i >= 0) st.items[i] = message;
      const row = $(`.msg-row[data-msg-id="${message.id}"]`);
      if (row) $('.msg-text', row).innerHTML = renderContent(message.content) + (message.editedAt ? '<span class="msg-edited">(edited)</span>' : '');
      break;
    }

    case 'msg:deleted': {
      const { chatId, messageId, byMod } = data;
      const st = S.msg[chatId];
      if (st) {
        const i = st.items.findIndex((m) => String(m.id) === String(messageId));
        if (i >= 0) st.items.splice(i, 1);
      }
      const row = $(`.msg-row[data-msg-id="${messageId}"]`);
      row?.remove();
      if (String(S.user.id) !== '' && byMod) toast('A message was removed by staff', 'info', 2200);
      break;
    }

    case 'chat:new':
    case 'chat:updated': {
      upsertChat(data.chat);
      renderChatList($('#chat-filter')?.value || '');
      if (S.activeChatId === data.chat.id && t === 'chat:updated') {
        renderChatPane(getChat(data.chat.id));
        renderMessages(data.chat.id, { keepScroll: true });
      }
      if (t === 'chat:new') toast(`You were added to “${chatTitle(data.chat)}”`, 'info', 2600);
      break;
    }

    case 'chat:removed': {
      const i = S.chats.findIndex((c) => c.id === data.chatId);
      const was = i >= 0 ? S.chats[i] : null;
      if (i >= 0) S.chats.splice(i, 1);
      delete S.msg[data.chatId];
      renderChatList($('#chat-filter')?.value || '');
      if (S.activeChatId === data.chatId) closeChat();
      if (was) toast(`Removed from “${chatTitle(was)}”`, 'info');
      break;
    }

    case 'presence': {
      if (data.online) S.online.add(data.userId);
      else S.online.delete(data.userId);
      refreshPresenceDots();
      updateChatSub();
      break;
    }

    case 'typing': {
      const { chatId, user, typing } = data;
      if (user.id === S.user.id) break;
      let tm = S.typing.get(chatId);
      if (!tm) { tm = new Map(); S.typing.set(chatId, tm); }
      if (typing) {
        clearTimeout(tm.get(user.id)?.timer);
        tm.set(user.id, {
          user,
          timer: setTimeout(() => { tm.delete(user.id); renderTypingBar(); }, 3500),
        });
      } else tm.delete(user.id);
      renderTypingBar();
      break;
    }

    case 'read': {
      const { chatId, userId, messageId } = data;
      const chat = getChat(chatId);
      const member = chat?.members.find((m) => m.id === userId);
      if (member) member.lastRead = Math.max(member.lastRead || 0, messageId);
      if (userId === S.user.id && chat) {
        chat.unread = 0;
        renderChatList($('#chat-filter')?.value || '');
      }
      updateReadStatus();
      break;
    }

    case 'user:self': {
      S.user = { ...S.user, ...data.user };
      store.saveSession(S.base, { token: S.token, user: S.user });
      syncSelfUi();
      break;
    }

    case 'user:updated': {
      const u = data.user;
      for (const c of S.chats) {
        const m = c.members.find((x) => x.id === u.id);
        if (m) Object.assign(m, u);
      }
      renderChatList($('#chat-filter')?.value || '');
      break;
    }

    case 'server:updated': {
      S.info = data.info;
      const t1 = $('.side-top .t1');
      if (t1) t1.textContent = data.info.name;
      toast(`Server settings updated`, 'info', 2200);
      break;
    }

    case 'force_logout': {
      if (S.selfRotate) break; // our own password change — reconnect already underway
      const reason = data.reason || 'You were signed out';
      S.wsManualClose = true;
      store.clearSession(S.base);
      S.token = null; S.user = null;
      showServerScreen(reason);
      break;
    }

    case 'error': {
      if (data.message) toast(data.message, 'error');
      break;
    }
  }
}

function refreshPresenceDots() {
  $$('.presence[data-pid]').forEach((el) => {
    el.classList.toggle('on', S.online.has(el.dataset.pid));
  });
}

function updateChatSub() {
  const chat = getChat(S.activeChatId);
  const el = $('#chat-sub');
  if (!chat || !el) return;
  if (chat.type === 'group') {
    el.textContent = `${chat.members.length} member${chat.members.length === 1 ? '' : 's'} · ${chat.members.filter((m) => S.online.has(m.id)).length} online`;
  } else {
    const peer = chatPeer(chat);
    el.innerHTML = peer
      ? (S.online.has(peer.id) ? '<span class="accent">online</span>' : esc(fmtLastSeen(peer.lastSeen)))
      : 'notes to yourself';
  }
}

function renderTypingBar() {
  const el = $('#typing-area');
  if (!el) return;
  const tm = S.typing.get(S.activeChatId);
  if (!tm || !tm.size) { el.innerHTML = ''; return; }
  const names = [...tm.values()].map((x) => x.user.displayName).slice(0, 3);
  const label = names.length === 1 ? `${names[0]} is typing` : names.join(', ') + ' are typing';
  el.innerHTML = `<span class="typing-dots"><i></i><i></i><i></i></span> ${esc(label)}`;
  setTimeout(updateReadStatus, 0);
}

function syncSelfUi() {
  const chip = $('#me-chip');
  if (chip) {
    chip.innerHTML = `${avatarHtml(S.user, 'sm')}
      <div class="grow" style="min-width:0">
        <div class="uc-name">${esc(S.user.displayName)}</div>
        <div class="uc-role">${esc(S.user.role)}</div>
      </div>`;
  }
  const isStaff = roleLevel(S.user.role) >= 1;
  const panelBtn = $('#panel-btn');
  if (isStaff && !panelBtn) {
    const b = document.createElement('button');
    b.className = 'btn btn-icon';
    b.id = 'panel-btn';
    b.title = 'Staff panel';
    b.innerHTML = icons.shield;
    b.onclick = () => openPanel();
    $('#settings-btn')?.before(b);
  } else if (!isStaff && panelBtn) {
    panelBtn.remove();
    if (S.panel.open) closePanel();
  }
  renderMuteBanner();
}

/* -------------------------- members drawer -------------------------- */

let drawerState = { chatId: null };

function openMembersDrawer(chatId) {
  const chat = getChat(chatId);
  if (!chat) return;
  drawerState.chatId = chatId;

  let backdrop = $('.drawer-backdrop');
  if (!backdrop) {
    backdrop = document.createElement('div');
    backdrop.className = 'drawer-backdrop';
    document.body.appendChild(backdrop);
    backdrop.addEventListener('click', closeDrawer);
  }
  let drawer = $('.drawer');
  if (!drawer) {
    drawer = document.createElement('div');
    drawer.className = 'drawer';
    document.body.appendChild(drawer);
  }

  const isCreator = chat.createdBy === S.user.id;
  const peer = chatPeer(chat);
  const rows = chat.members.map((m) => `
    <div class="member-row" data-member="${esc(m.id)}">
      ${avatarHtml(m, 'sm', chat.type === 'group')}
      <div class="grow" style="min-width:0">
        <div class="m-name">${esc(m.displayName)} ${roleBadge(m.role)}</div>
        <div class="m-status ${S.online.has(m.id) ? 'online' : ''}">@${esc(m.username)} · ${S.online.has(m.id) ? 'online' : esc(fmtLastSeen(m.lastSeen))}</div>
      </div>
      ${chat.type === 'group' && m.id !== S.user.id && (isCreator || roleLevel(S.user.role) >= 1) && m.id !== chat.createdBy
        ? `<button class="btn btn-ghost btn-icon" data-kick-member="${esc(m.id)}" title="Remove from group">${icons.x}</button>` : ''}
    </div>`).join('');

  drawer.innerHTML = `
    <div class="drawer-head">
      ${chatAvatar(chat, 'sm', false)}
      <div class="grow" style="min-width:0">
        <div style="font-weight:750">${esc(chatTitle(chat))}</div>
        <div class="small faint">${chat.type === 'group' ? `${chat.members.length} members` : peer ? '@' + esc(peer.username) : 'Your private space'}</div>
      </div>
      <button class="btn btn-ghost btn-icon" id="drawer-close">${icons.x}</button>
    </div>
    <div class="drawer-body">
      ${chat.type === 'group' ? `
        <div class="row mb-3">
          <button class="btn btn-sm grow" id="drawer-add">${icons.plus}<span>Add members</span></button>
          <button class="btn btn-sm grow" id="drawer-rename">${icons.pencil}<span>Rename</span></button>
        </div>` : peer ? `<button class="btn btn-block btn-sm mb-3" id="drawer-view-user">${icons.user}<span>View profile</span></button>` : ''}
      <div class="list-label" style="padding:4px 4px 8px">Members</div>
      ${rows}
      ${chat.type === 'group' ? `<button class="btn btn-danger btn-block mt-4" id="drawer-leave">${icons.logout}<span>Leave group</span></button>` : ''}
    </div>`;

  $('#drawer-close', drawer).onclick = closeDrawer;
  $('#drawer-add', drawer)?.addEventListener('click', () => openAddMembers(chatId));
  $('#drawer-rename', drawer)?.addEventListener('click', async () => {
    const vals = await formModal({
      title: 'Rename group',
      fields: [{ key: 'name', label: 'Group name', value: chat.name }],
    });
    if (vals?.name?.trim()) {
      try {
        await api(`/api/chats/${encodeURIComponent(chatId)}`, { method: 'PATCH', body: { name: vals.name.trim() } });
        toast('Group renamed', 'success');
      } catch (e) { toast(e.message, 'error'); }
    }
  });
  $('#drawer-leave', drawer)?.addEventListener('click', async () => {
    if (await confirmModal({ title: 'Leave group?', confirmText: 'Leave', danger: true })) {
      try {
        await api(`/api/chats/${encodeURIComponent(chatId)}/members/${encodeURIComponent(S.user.id)}`, { method: 'DELETE' });
        closeDrawer();
      } catch (e) { toast(e.message, 'error'); }
    }
  });
  $$('#drawer-view-user', drawer).forEach((b) => b.addEventListener('click', () => {
    if (peer) toast(`@${peer.username} — ${roleLevel(peer.role) > 0 ? peer.role : 'member'}`, 'info');
  }));
  $$('[data-kick-member]', drawer).forEach((b) => b.addEventListener('click', async () => {
    const uid = b.dataset.kickMember;
    const m = chat.members.find((x) => x.id === uid);
    if (await confirmModal({ title: `Remove ${m?.displayName}?`, confirmText: 'Remove', danger: true })) {
      try {
        await api(`/api/chats/${encodeURIComponent(chatId)}/members/${encodeURIComponent(uid)}`, { method: 'DELETE' });
      } catch (e) { toast(e.message, 'error'); }
    }
  }));

  requestAnimationFrame(() => { backdrop.classList.add('open'); drawer.classList.add('open'); });
}

function closeDrawer() {
  $('.drawer-backdrop')?.classList.remove('open');
  $('.drawer')?.classList.remove('open');
  drawerState.chatId = null;
}

/* ------------------------- new chat / add members ------------------------- */

async function searchPickList(container, { multi = false, onPick = null, selected = new Set() } = {}) {
  const input = $('.input', container);
  const list = $('.new-chat-list', container);
  let timer = null;
  const run = async () => {
    const q = input.value.trim();
    if (!q) { list.innerHTML = '<div class="empty-note">Type to search for users</div>'; return; }
    try {
      const { users } = await api(`/api/users/search?q=${encodeURIComponent(q)}`);
      if (!users.length) { list.innerHTML = '<div class="empty-note">No users found</div>'; return; }
      list.innerHTML = users.map((u) => `
        <div class="pick-row ${selected.has(u.id) ? 'selected' : ''}" data-uid="${esc(u.id)}" data-uname="${esc(u.displayName)}" data-color="${esc(u.avatarColor)}">
          ${avatarHtml(u, 'sm', true)}
          <div class="grow" style="min-width:0">
            <div style="font-weight:650">${esc(u.displayName)}</div>
            <div class="small faint">@${esc(u.username)} ${roleLevel(u.role) >= 1 ? '· ' + esc(u.role) : ''}</div>
          </div>
          ${selected.has(u.id) ? `<span style="color:var(--success)">${icons.check}</span>` : ''}
        </div>`).join('');
      $$('.pick-row', list).forEach((row) => row.addEventListener('click', () => {
        if (multi) {
          const id = row.dataset.uid;
          if (selected.has(id)) selected.delete(id);
          else selected.set(id, { id, displayName: row.dataset.uname, avatarColor: row.dataset.color });
          row.classList.toggle('selected', selected.has(id));
          run();
        } else onPick?.(row.dataset.uid);
      }));
    } catch (e) { list.innerHTML = `<div class="empty-note">${esc(e.message)}</div>`; }
  };
  input.addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(run, 280); });
  input.addEventListener('keydown', (e) => { if (e.key === 'Enter') run(); });
  input.value = '';
  await run();
}

function openNewChat() {
  let mode = 'dm';
  const selected = new Map();
  openModal(`
    <div class="modal-head"><div class="modal-title">New chat</div></div>
    <div class="auth-tabs">
      <div class="tab-pill" id="nc-pill"></div>
      <button class="active" id="nc-dm">Direct</button>
      <button id="nc-group">Group</button>
    </div>
    <div id="nc-body"></div>
  `, {
    onMount: async (root, close) => {
      const body = $('#nc-body', root);
      const pill = $('#nc-pill', root);

      const mountDm = async () => {
        body.innerHTML = `
          <div class="field"><label>Find a user</label><input class="input" placeholder="Search by username…" /></div>
          <div class="new-chat-list"></div>`;
        await searchPickList(body, {
          onPick: async (uid) => {
            try {
              const { chat } = await api('/api/chats/dm', { method: 'POST', body: { userId: uid } });
              upsertChat(chat);
              renderChatList($('#chat-filter')?.value || '');
              close();
              openChat(chat.id);
            } catch (e) { toast(e.message, 'error'); }
          },
        });
      };

      const mountGroup = async () => {
        body.innerHTML = `
          <div class="field"><label>Group name</label><input class="input" id="g-name" placeholder="My awesome group" maxlength="64" /></div>
          <div class="field"><label>Add members</label><input class="input" id="g-search" placeholder="Search by username…" /></div>
          <div class="new-chat-list"></div>
          <button class="btn btn-primary btn-block mt-3" id="g-create">${icons.users}<span>Create group</span></button>`;
        await searchPickList(body, { multi: true, selected });
        $('#g-create', body).onclick = async () => {
          const name = $('#g-name', body).value.trim();
          if (!name) return toast('Give the group a name', 'error');
          try {
            const { chat } = await api('/api/chats/group', {
              method: 'POST', body: { name, memberIds: [...selected.keys()] },
            });
            upsertChat(chat);
            renderChatList($('#chat-filter')?.value || '');
            close();
            openChat(chat.id);
          } catch (e) { toast(e.message, 'error'); }
        };
      };

      $('#nc-dm', root).onclick = () => {
        mode = 'dm';
        pill.classList.remove('right');
        $('#nc-dm', root).classList.add('active');
        $('#nc-group', root).classList.remove('active');
        mountDm();
      };
      $('#nc-group', root).onclick = () => {
        mode = 'group';
        pill.classList.add('right');
        $('#nc-group', root).classList.add('active');
        $('#nc-dm', root).classList.remove('active');
        mountGroup();
      };
      void mode;
      mountDm();
    },
  });
}

function openAddMembers(chatId) {
  const selected = new Map();
  const chat = getChat(chatId);
  openModal(`
    <div class="modal-head"><div class="modal-title">Add members</div></div>
    <div class="field"><label>Find users</label><input class="input" placeholder="Search by username…" /></div>
    <div class="new-chat-list"></div>
    <button class="btn btn-primary btn-block mt-3" id="add-go">${icons.plus}<span>Add selected</span></button>
  `, {
    onMount: async (root, close) => {
      await searchPickList(root, { multi: true, selected });
      $('#add-go', root).onclick = async () => {
        if (!selected.size) return close();
        try {
          const existing = new Set((chat?.members || []).map((m) => m.id));
          const ids = [...selected.keys()].filter((id) => !existing.has(id));
          if (ids.length) await api(`/api/chats/${encodeURIComponent(chatId)}/members`, { method: 'POST', body: { userIds: ids } });
          toast('Members added', 'success');
          close();
        } catch (e) { toast(e.message, 'error'); }
      };
    },
  });
}

/* ------------------------------ settings ------------------------------ */

function openSettings() {
  const accents = ['#6366f1', '#22d3ee', '#f472b6', '#fbbf24', '#34d399'];
  openModal(`
    <div class="modal-head"><div class="modal-title">Settings</div></div>

    <div class="card">
      <h3>Profile</h3>
      <div class="row mb-3">${avatarHtml(S.user, '')}
        <div><div style="font-weight:700">${esc(S.user.displayName)}</div>
        <div class="small faint">@${esc(S.user.username)} · ${roleBadge(S.user.role)}</div></div>
      </div>
      <div class="field"><label>Display name</label><input class="input" id="set-name" maxlength="40" value="${esc(S.user.displayName)}" /></div>
      <button class="btn btn-primary btn-sm" id="set-save-name">Save name</button>
    </div>

    <div class="card">
      <h3>Appearance</h3>
      <div class="row between mb-3"><span class="small">Theme</span>
        <button class="btn btn-sm" id="set-theme">${S.prefs.theme === 'dark' ? icons.moon + '<span>Dark</span>' : icons.sun + '<span>Light</span>'}</button>
      </div>
      <div class="row between"><span class="small">Accent color</span>
        <div class="seg">${accents.map((a) => `<div class="swatch ${S.prefs.accent === a ? 'active' : ''}" data-accent="${a}" style="background:${a}"></div>`).join('')}</div>
      </div>
      <div class="row between mt-3"><span class="small">Message sound</span>
        <label class="toggle"><input type="checkbox" id="set-sound" ${S.prefs.sound ? 'checked' : ''} /><span class="track"></span></label>
      </div>
    </div>

    <div class="card">
      <h3>Security</h3>
      <div class="field"><label>Current password</label><input class="input" id="set-cur" type="password" autocomplete="current-password" /></div>
      <div class="field"><label>New password (min. 8 chars)</label><input class="input" id="set-new" type="password" autocomplete="new-password" /></div>
      <div class="row">
        <button class="btn btn-sm" id="set-pass">${icons.key}<span>Change password</span></button>
        <button class="btn btn-sm btn-ghost" id="set-saved">${'🔖'}<span>Saved messages</span></button>
      </div>
    </div>

    <div class="small faint" style="text-align:center;padding-bottom:6px">efadro web · connected to ${esc(S.base)}</div>
  `, {
    onMount(root, close) {
      $('#set-save-name', root).onclick = async () => {
        try {
          const { user } = await api('/api/auth/me', { method: 'PATCH', body: { displayName: $('#set-name', root).value.trim() } });
          S.user = user;
          store.saveSession(S.base, { token: S.token, user: S.user });
          syncSelfUi();
          renderChatList($('#chat-filter')?.value || '');
          toast('Display name updated', 'success');
        } catch (e) { toast(e.message, 'error'); }
      };
      $('#set-theme', root).onclick = (e) => {
        S.prefs.theme = S.prefs.theme === 'dark' ? 'light' : 'dark';
        store.savePrefs(S.prefs);
        applyPrefs();
        e.currentTarget.innerHTML = S.prefs.theme === 'dark' ? icons.moon + '<span>Dark</span>' : icons.sun + '<span>Light</span>';
      };
      $$('.swatch', root).forEach((sw) => sw.addEventListener('click', () => {
        S.prefs.accent = sw.dataset.accent;
        store.savePrefs(S.prefs);
        applyPrefs();
        $$('.swatch', root).forEach((x) => x.classList.toggle('active', x === sw));
      }));
      $('#set-sound', root).onchange = (e) => {
        S.prefs.sound = e.target.checked;
        store.savePrefs(S.prefs);
      };
      $('#set-pass', root).onclick = async () => {
        const cur = $('#set-cur', root).value;
        const next = $('#set-new', root).value;
        if (!cur || next.length < 8) return toast('New password must be at least 8 characters', 'error');
        try {
          S.selfRotate = true; // server kicks our own socket on password change — expect it
          const j = await api('/api/auth/change-password', { method: 'POST', body: { current: cur, next } });
          S.token = j.token;
          store.saveSession(S.base, { token: S.token, user: S.user });
          close();
          toast('Password changed — other sessions were signed out', 'success');
          S.wsManualClose = true;
          try { S.ws?.close(); } catch { /* ignore */ }
          connectWS(); // reconnect with the fresh token
          setTimeout(() => { S.selfRotate = false; }, 1500);
        } catch (e) { S.selfRotate = false; toast(e.message, 'error'); }
      };
      $('#set-saved', root).onclick = async () => {
        try {
          const { chat } = await api('/api/chats/dm', { method: 'POST', body: { userId: S.user.id } });
          upsertChat(chat);
          renderChatList($('#chat-filter')?.value || '');
          close();
          openChat(chat.id);
        } catch (e) { toast(e.message, 'error'); }
      };
    },
  });
}

/* ============================ STAFF PANEL ============================ */

function openPanel() {
  if (roleLevel(S.user.role) < 1) return;
  S.panel.open = true;
  const me = roleLevel(S.user.role);
  const overlay = document.createElement('div');
  overlay.className = 'panel-overlay';
  overlay.id = 'panel-overlay';
  overlay.innerHTML = `
    <div class="panel-top">
      <div class="logo logo-sm" style="width:34px;height:34px;font-size:18px;border-radius:10px">${icons.shield}</div>
      <div>
        <div class="panel-title">Staff panel</div>
        <div class="small faint">You are signed in as ${esc(S.user.role)}</div>
      </div>
      <div class="panel-nav">
        <button data-tab="users" class="active">${icons.user} Users</button>
        <button data-tab="reports">${icons.flag} Reports <span id="rep-count"></span></button>
        ${me >= 2 ? `<button data-tab="audit">${icons.activity} Audit log</button>` : ''}
        ${me >= 3 ? `<button data-tab="server">${icons.gear} Server</button>` : ''}
      </div>
      <div class="grow"></div>
      <button class="btn btn-icon" id="panel-close" title="Close">${icons.x}</button>
    </div>
    <div class="panel-body"><div class="panel-inner" id="panel-content"></div></div>`;
  document.body.appendChild(overlay);
  $('#panel-close', overlay).onclick = closePanel;
  $$('.panel-nav button', overlay).forEach((b) => b.addEventListener('click', () => {
    $$('.panel-nav button', overlay).forEach((x) => x.classList.toggle('active', x === b));
    S.panel.tab = b.dataset.tab;
    renderPanelTab();
  }));
  document.addEventListener('keydown', panelEsc);
  renderPanelTab();
}

function panelEsc(e) { if (e.key === 'Escape' && S.panel.open && !modalRoot.hasChildNodes()) closePanel(); }

function closePanel() {
  S.panel.open = false;
  $('#panel-overlay')?.remove();
  document.removeEventListener('keydown', panelEsc);
}

async function renderPanelTab() {
  const el = $('#panel-content');
  if (!el) return;
  const tab = S.panel.tab;
  el.innerHTML = '<div class="empty-note"><span class="spinner"></span></div>';
  try {
    if (tab === 'users') return renderPanelUsers(el);
    if (tab === 'reports') return renderPanelReports(el);
    if (tab === 'audit') return renderPanelAudit(el);
    if (tab === 'server') return renderPanelServer(el);
  } catch (e) {
    el.innerHTML = `<div class="empty-note">${esc(e.message)}</div>`;
  }
}

async function panelStats(el) {
  const { stats } = await api('/api/admin/stats');
  const items = [
    [stats.online, 'Online now'], [stats.users, 'Total users'], [stats.chats, 'Chats'],
    [stats.messages, 'Messages'], [stats.banned, 'Banned'], [stats.openReports, 'Open reports'],
  ];
  el.insertAdjacentHTML('afterbegin', `<div class="stat-grid">${items.map(([n, l], i) =>
    `<div class="stat-card" style="animation-delay:${i * 45}ms"><div class="s-num">${n}</div><div class="s-label">${esc(l)}</div></div>`).join('')}</div>`);
  const rc = $('#rep-count');
  if (rc) rc.textContent = stats.openReports ? `(${stats.openReports})` : '';
}

/* ----------------------------- panel: users ----------------------------- */

async function renderPanelUsers(el, q = '') {
  const { users } = await api(`/api/admin/users${q ? `?q=${encodeURIComponent(q)}` : ''}`);
  el.innerHTML = `
    <div class="row mb-3">
      <div class="search-box grow">${icons.search}<input class="input" id="pu-search" placeholder="Search users…" value="${esc(q)}" /></div>
    </div>
    <div class="card" style="padding:6px 14px">
      <table class="utable">
        <thead><tr><th>User</th><th>Role</th><th>Status</th><th>Joined</th><th></th></tr></thead>
        <tbody>
          ${users.map((u) => `
          <tr data-uid="${esc(u.id)}">
            <td><div class="u-cell">${avatarHtml(u, 'xs')}
              <div><div style="font-weight:650">${esc(u.displayName)} ${u.isBootstrapOwner ? '<span title="Bootstrap owner">👑</span>' : ''}</div>
              <div class="small faint">@${esc(u.username)}${u.online ? ' · <span style="color:var(--success)">online</span>' : ''}</div></div>
            </div></td>
            <td>${roleBadge(u.role)}</td>
            <td>${u.banned ? `<span class="pill bad">banned</span>`
              : (u.mutedUntil > Date.now() ? `<span class="pill warn">muted</span>` : '<span class="pill ok">active</span>')}</td>
            <td class="faint small">${new Date(u.createdAt).toLocaleDateString()}</td>
            <td style="text-align:right">${u.id !== S.user.id ? `<button class="btn btn-ghost btn-icon pu-actions" data-uid="${esc(u.id)}">${icons.dots}</button>` : '<span class="faint small">you</span>'}</td>
          </tr>`).join('')}
        </tbody>
      </table>
      ${!users.length ? '<div class="empty-note">No users found</div>' : ''}
    </div>`;

  await panelStats(el);

  let timer = null;
  $('#pu-search', el).addEventListener('input', (e) => {
    clearTimeout(timer);
    timer = setTimeout(() => renderPanelUsers(el, e.target.value.trim()), 300);
  });

  $$('.pu-actions', el).forEach((btn) => btn.addEventListener('click', (e) => {
    const u = users.find((x) => x.id === btn.dataset.uid);
    if (!u) return;
    const rect = e.currentTarget.getBoundingClientRect();
    userAdminMenu(rect.left - 170, rect.bottom + 6, u, () => renderPanelUsers(el, q));
  }));
}

function userAdminMenu(x, y, u, refresh) {
  const me = roleLevel(S.user.role);
  const target = roleLevel(u.role);
  const canManage = me > target;
  const muted = u.mutedUntil > Date.now();
  const items = [];

  // Role changes (admin+)
  if (me >= 2 && canManage && !u.isBootstrapOwner) {
    const roles = [];
    if (u.role !== 'moderator') roles.push('moderator');
    roles.push('user');
    if (me >= 3 && u.role !== 'admin') roles.push('admin');
    if (me >= 3 && u.role !== 'owner') roles.push('owner');
    for (const r of roles) {
      items.push({
        label: `Make ${r}`, icon: icons.shield,
        onClick: () => adminAct(`/api/admin/users/${u.id}/role`, { role: r }, `Role updated`, refresh),
      });
    }
    items.push({ sep: true });
  }

  // Mute (moderator+) — the bootstrap owner is protected server-side too
  if (canManage && !u.isBootstrapOwner) {
    if (muted) items.push({ label: 'Unmute', icon: icons.mute, onClick: () => adminAct(`/api/admin/users/${u.id}/unmute`, {}, 'Unmuted', refresh) });
    else items.push({
      label: 'Mute…', icon: icons.mute,
      onClick: async () => {
        const vals = await formModal({
          title: `Mute ${u.displayName}`,
          fields: [
            { key: 'minutes', label: 'Duration', type: 'select', value: '60', options: [
              { value: '5', label: '5 minutes' }, { value: '15', label: '15 minutes' },
              { value: '60', label: '1 hour' }, { value: '1440', label: '1 day' },
              { value: '10080', label: '1 week' }, { value: '43200', label: '30 days' },
            ] },
            { key: 'reason', label: 'Reason (optional)', placeholder: 'Spam, harassment…' },
          ],
          submitText: 'Mute', danger: true,
        });
        if (vals) adminAct(`/api/admin/users/${u.id}/mute`, { minutes: Number(vals.minutes), reason: vals.reason }, 'Muted', refresh);
      },
    });
    items.push({
      label: 'Kick (sign out)', icon: icons.kick,
      onClick: async () => {
        if (await confirmModal({ title: `Sign out ${u.displayName}?`, body: 'All their sessions will be terminated.', confirmText: 'Kick', danger: true })) {
          adminAct(`/api/admin/users/${u.id}/kick`, {}, 'Kicked', refresh);
        }
      },
    });
  }

  // Ban (admin+)
  if (me >= 2 && canManage && !u.isBootstrapOwner) {
    if (u.banned) items.push({ label: 'Unban', icon: icons.check, onClick: () => adminAct(`/api/admin/users/${u.id}/unban`, {}, 'Unbanned', refresh) });
    else items.push({
      label: 'Ban…', icon: icons.ban, danger: true,
      onClick: async () => {
        const vals = await formModal({
          title: `Ban ${u.displayName}`,
          note: 'They will be signed out immediately and cannot sign in again until unbanned.',
          fields: [{ key: 'reason', label: 'Reason (optional)', placeholder: 'Rule violation…' }],
          submitText: 'Ban user', danger: true,
        });
        if (vals) adminAct(`/api/admin/users/${u.id}/ban`, { reason: vals.reason }, 'Banned', refresh);
      },
    });
  }

  if (!items.length) items.push({ label: 'No actions available', disabled: true });
  ctxMenu(x, y, items);
}

async function adminAct(url, body, okMsg, refresh) {
  try {
    await api(url, { method: url.includes('/role') ? 'PATCH' : 'POST', body });
    toast(okMsg, 'success');
    refresh?.();
  } catch (e) { toast(e.message, 'error'); }
}

/* ---------------------------- panel: reports ---------------------------- */

async function renderPanelReports(el) {
  const { reports } = await api('/api/admin/reports');
  el.innerHTML = `
    <div class="small muted mb-3">Reports from users. Deleting a message also resolves its report.</div>
    ${reports.length ? reports.map((r) => `
      <div class="card report-card" data-rid="${r.id}" data-mid="${r.message.id}">
        <div class="report-msg">${esc(r.message.content)}</div>
        <div class="report-meta">
          <span>Author: <b>${esc(r.author.displayName)}</b> (@${esc(r.author.username)})</span>
          <span>Reported by: ${esc(r.reporter.displayName)}</span>
          <span>${timeAgo(r.createdAt)}</span>
        </div>
        ${r.reason ? `<div class="small" style="color:var(--warning)">“${esc(r.reason)}”</div>` : ''}
        <div class="row mt-2">
          <button class="btn btn-sm btn-danger" data-act="del">${icons.trash}<span>Delete message</span></button>
          <button class="btn btn-sm" data-act="mute">${icons.mute}<span>Mute author</span></button>
          <div class="grow"></div>
          <button class="btn btn-sm btn-ghost" data-act="dismiss">Dismiss</button>
        </div>
      </div>`).join('') : '<div class="empty-note">No open reports — all clear ✨</div>'}`;

  await panelStats(el);

  $$('.report-card', el).forEach((card) => {
    const rid = card.dataset.rid;
    const mid = card.dataset.mid;
    card.addEventListener('click', async (e) => {
      const b = e.target.closest('button[data-act]');
      if (!b) return;
      const act = b.dataset.act;
      try {
        if (act === 'del') {
          await api(`/api/messages/${mid}`, { method: 'DELETE' });
          await api(`/api/admin/reports/${rid}/resolve`, { method: 'POST', body: {} });
          toast('Message deleted & report resolved', 'success');
          renderPanelTab();
        } else if (act === 'dismiss') {
          await api(`/api/admin/reports/${rid}/resolve`, { method: 'POST', body: {} });
          renderPanelTab();
        } else if (act === 'mute') {
          const authorId = reports.find((x) => String(x.id) === String(rid))?.author?.id;
          const vals = await formModal({
            title: 'Mute author',
            fields: [
              { key: 'minutes', label: 'Duration', type: 'select', value: '60', options: [
                { value: '15', label: '15 minutes' }, { value: '60', label: '1 hour' },
                { value: '1440', label: '1 day' }, { value: '10080', label: '1 week' },
              ] },
              { key: 'reason', label: 'Reason (optional)' },
            ],
            submitText: 'Mute', danger: true,
          });
          if (vals && authorId) {
            await api(`/api/admin/users/${authorId}/mute`, { method: 'POST', body: { minutes: Number(vals.minutes), reason: vals.reason } });
            await api(`/api/admin/reports/${rid}/resolve`, { method: 'POST', body: {} });
            toast('Author muted & report resolved', 'success');
            renderPanelTab();
          }
        }
      } catch (err) { toast(err.message, 'error'); }
    });
  });
}

/* ----------------------------- panel: audit ----------------------------- */

const AUDIT_LABELS = {
  ban: 'banned', unban: 'unbanned', mute: 'muted', unmute: 'unmuted', kick: 'kicked',
  role_change: 'changed role of', message_delete: 'deleted a message by', report_resolve: 'resolved a report on',
  config_update: 'updated server config', secret_rotate: 'rotated server keys', signup: 'joined the server', password_change: 'changed password',
};

async function renderPanelAudit(el) {
  const { entries } = await api('/api/admin/audit');
  el.innerHTML = `
    <div class="card">
      <h3>Audit log</h3>
      ${entries.length ? entries.map((a) => `
        <div class="audit-row">
          <span class="audit-action">${esc(a.action)}</span>
          <span class="grow">${esc(a.actor?.displayName || '?')} ${esc(AUDIT_LABELS[a.action] || '')} ${a.target ? `<b>${esc(a.target.displayName)}</b>` : ''}
            ${a.meta && Object.keys(a.meta).length ? `<span class="faint"> ${esc(JSON.stringify(a.meta))}</span>` : ''}</span>
          <span class="audit-time">${timeAgo(a.createdAt)}</span>
        </div>`).join('') : '<div class="empty-note">No activity yet</div>'}
    </div>`;
  await panelStats(el);
}

/* ----------------------------- panel: server ----------------------------- */

async function renderPanelServer(el) {
  const { config: c } = await api('/api/admin/server/config');
  el.innerHTML = `
    <div class="card">
      <h3>General</h3>
      <div class="field"><label>Server name</label><input class="input" id="sc-name" maxlength="80" value="${esc(c.serverName)}" /></div>
      <div class="row between">
        <div><div class="small" style="font-weight:650">Open registration</div>
        <div class="small faint">Allow new accounts to sign up</div></div>
        <label class="toggle"><input type="checkbox" id="sc-reg" ${c.registrationEnabled ? 'checked' : ''} /><span class="track"></span></label>
      </div>
    </div>

    <div class="card">
      <h3>Server password</h3>
      <div class="small faint mb-3">New members must enter this password before they can register or sign in. Leave empty to disable. ${c.serverPasswordSet ? '<span class="pill ok">enabled</span>' : '<span class="pill warn">disabled</span>'}</div>
      <div class="field"><label>Server password</label><input class="input" id="sc-pass" type="text" placeholder="Enter a new password…" autocomplete="off" /></div>
      <div class="small faint">Saving replaces the current password; saving with an empty field disables it.</div>
    </div>

    <div class="card">
      <h3>Cloudflare Turnstile</h3>
      <div class="row between mb-3">
        <div><div class="small" style="font-weight:650">Require captcha on join</div>
        <div class="small faint">Visitors must solve a Turnstile challenge first</div></div>
        <label class="toggle"><input type="checkbox" id="sc-ts" ${c.turnstile.enabled ? 'checked' : ''} /><span class="track"></span></label>
      </div>
      <div class="field"><label>Site key</label><input class="input mono" id="sc-ts-site" value="${esc(c.turnstile.siteKey)}" placeholder="0x4AAAAAAA…" /></div>
      <div class="field"><label>Secret key ${c.turnstile.secretKeySet ? `<span class="faint">(currently ${esc(c.turnstile.secretKeyMasked)})</span>` : ''}</label>
        <input class="input mono" id="sc-ts-secret" value="" placeholder="${c.turnstile.secretKeySet ? 'Leave empty to keep current' : '0x4AAAAAAA…'}" autocomplete="off" /></div>
    </div>

    <div class="card">
      <h3>Sessions</h3>
      <div class="field"><label>Session length (days)</label><input class="input" id="sc-days" type="number" min="1" max="90" value="${c.tokenExpiryDays}" /></div>
    </div>

    <button class="btn btn-primary" id="sc-save">${icons.check}<span>Save settings</span></button>

    <div class="card mt-4" style="border-color:color-mix(in srgb, var(--danger) 30%, transparent)">
      <h3 style="color:var(--danger)">Danger zone</h3>
      <div class="small faint mb-3">Rotating the JWT secret signs out <b>everyone</b> (including you) and invalidates all sessions. Current secret: <code>${esc(c.jwtSecretMasked)}</code></div>
      <button class="btn btn-danger" id="sc-rotate">${icons.refresh}<span>Rotate JWT secret</span></button>
    </div>`;

  $('#sc-save', el).onclick = async () => {
    const body = {
      serverName: $('#sc-name', el).value.trim(),
      registrationEnabled: $('#sc-reg', el).checked,
      serverPassword: $('#sc-pass', el).value,
      turnstileEnabled: $('#sc-ts', el).checked,
      turnstileSiteKey: $('#sc-ts-site', el).value.trim(),
      tokenExpiryDays: Number($('#sc-days', el).value) || 7,
    };
    const secret = $('#sc-ts-secret', el).value.trim();
    if (secret) body.turnstileSecretKey = secret;
    try {
      await api('/api/admin/server/config', { method: 'PATCH', body });
      toast('Server settings saved', 'success');
      renderPanelServer(el);
    } catch (e) { toast(e.message, 'error'); }
  };

  $('#sc-rotate', el).onclick = async () => {
    if (await confirmModal({ title: 'Rotate JWT secret?', body: 'Every user will be signed out immediately, including you.', confirmText: 'Rotate', danger: true })) {
      try { await api('/api/admin/server/regenerate-secret', { method: 'POST', body: {} }); } catch { /* session dies immediately */ }
    }
  };

  await panelStats(el);
}

/* ------------------------------- events ------------------------------- */

// Chat list open
document.addEventListener('click', (e) => {
  const item = e.target.closest('.chat-item[data-chat-id]');
  if (item) openChat(item.dataset.chatId);
});

// Image lightbox
document.addEventListener('click', (e) => {
  const img = e.target.closest('.msg-img');
  if (!img) return;
  openModal(`<img src="${esc(img.src)}" style="max-width:100%;border-radius:14px;display:block" alt="" />`, {
    onMount(root) { root.firstElementChild.style.width = 'min(720px, 94vw)'; },
  });
});

// Mark read when window regains focus
window.addEventListener('focus', () => { if (S.activeChatId) markRead(S.activeChatId); });

/* -------------------------------- boot -------------------------------- */

(function boot() {
  S.prefs = { theme: 'dark', accent: '#6366f1', sound: true, ...store.prefs };
  applyPrefs();
  showServerScreen();
})();
