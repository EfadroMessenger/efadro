![efadro](https://img.shields.io/badge/efadro-self--hosted%20messenger-6366f1)

# efadro

A complete **self-hosted messenger**: real-time chat over WebSocket, direct messages, group chats, and a full moderation system with four roles — all secured by a join gate (Cloudflare Turnstile captcha + server password) before anyone can even register.

Everything is configured from a single **`config.json`**, and the whole app (server + web client + SQLite database) runs as one Node process.

---

## ✨ Features

**Join flow (exactly as designed)**
1. User enters the **server URL**
2. Completes the **Cloudflare Turnstile captcha** *(only if enabled on the server)*
3. Enters the **server password** *(step is skipped when it’s empty in config)*
4. **Signs in / creates an account**
5. Lands in the **chat**

**Messaging**
- Direct messages + “Saved Messages” self-chat
- Group chats: create, rename, add/remove members, leave
- Real-time messages over WebSocket (with REST fallback), edit & delete
- Typing indicators, online presence, unread badges
- Read receipts (✓ Sent / ✓✓ Seen in DMs)
- Message search-by-user, link previews-in-text, image URL embedding, emoji picker
- Message reporting → lands in the moderators’ queue
- Sounds, desktop-style toasts, unread counter in the page title

**Roles & moderation (server-enforced hierarchy)**
| Role | Level | Powers |
|---|---|---|
| 👑 **Owner** | full control | everything + manage any role, edit server settings from the panel (writes `config.json`), rotate JWT secret |
| 🛡 **Admin** | medium | ban/unban, mute, kick, promote users ↔ moderator, audit log, resolve reports |
| 🔨 **Moderator** | low | mute/unmute, kick (force sign-out), delete messages of regular users, reports queue |
| 👤 **User** | none | normal chat |

Staff panel tabs: **Users** · **Reports** · **Audit log** · **Server settings** (owner only) — with live stats (online, users, chats, messages, bans).

**Misc**
- Dark / light theme, accent colors, animated aurora UI
- Fully responsive (mobile layout with collapsible sidebar)
- Recent-servers list + per-server sessions on the client
- The owner can change server name, server password, registration toggle and Turnstile keys **live from the UI** — they’re persisted back into `config.json`

---

## 🚀 Quick start

```bash
cd efadro
npm install
npm start
```

Then open **http://localhost:3000** — the web client is served by the same process.

On first start:
- `config.json` is created (a random `jwtSecret` is generated automatically)
- the **owner account** is created from `config.json` → default **`owner` / `efadro-owner`** — change it!
- the database goes to `./data/efadro.db`

> Sign in as `owner`, open the shield (**Staff panel**) → **Server** tab to set a server password, Turnstile keys, or close registration — no restart needed.

---

## ⚙️ `config.json` reference

```jsonc
{
  "serverName": "Efadro Server",     // shown in the UI
  "host": "0.0.0.0",                 // bind address
  "port": 3000,                      // HTTP port
  "serverPassword": "",              // join gate password; empty = no password step
  "jwtSecret": "…",                  // HMAC secret for tokens (auto-generated, keep private!)
  "tokenExpiryDays": 7,              // session lifetime

  "owner": {
    "username": "owner",             // bootstrap owner account
    "password": "efadro-owner",      // change this!
    "forceReset": false              // true → re-apply the password above on every boot
  },

  "turnstile": {
    "enabled": false,                // master switch
    "siteKey": "",                   // Cloudflare Turnstile site key (public)
    "secretKey": ""                  // Cloudflare Turnstile secret key (private)
  },

  "registration": { "enabled": true },

  "limits": {
    "maxMessageLength": 4000,
    "maxGroupNameLength": 64,
    "maxDisplayNameLength": 40,
    "maxGroupSize": 100
  },

  "rateLimit": {
    "enabled": true,
    "windowMs": 60000,
    "authPerMinute": 20,             // gate/login/signup attempts per IP
    "messagePerMinute": 120,         // messages per user
    "apiPerMinute": 600
  },

  "corsOrigins": ["*"]               // API CORS; restrict to your frontend origin if you like
}
```

Notes:
- Only changed keys need to be present — missing keys fall back to defaults and are filled in on boot.
- **Recovering access:** delete `data/` to start fresh, or set `owner.forceReset: true` with a new `owner.password` and restart.
- Environment overrides: `EFADRO_CONFIG=/path/config.json`, `EFADRO_DATA=/path/data-dir`, `EFADRO_TRUST_PROXY=1` (when behind nginx/Cloudflare, so rate limits use real IPs).

### Cloudflare Turnstile setup

1. Cloudflare dashboard → **Turnstile** → *Add site* → get your **site key** + **secret key**.
2. Put them in `config.json` under `turnstile` (or paste them in **Staff panel → Server** and flip the switch).
3. The captcha step now appears during the join flow.

For local development you can use Cloudflare’s always-pass test keys:
`siteKey: 1x00000000000000000000AA`, `secretKey: 1x0000000000000000000000000000000AA`.

---

## 🔐 Security

- Passwords hashed with **bcrypt** (cost 12)
- **JWT** sessions bound to a per-user token version — bans, kicks, password changes and secret rotation invalidate sessions instantly (connected sockets are dropped live)
- Join **gate tokens** (10 min TTL) are required before login/signup, so login brute-force can’t even start without captcha + server password
- Server-side **Turnstile verification** (siteverify API, with timeout)
- **Role hierarchy enforced on the server** for every moderation action; the bootstrap owner (from `config.json`) cannot be banned/demoted via the API
- Rate limiting on auth, messages and API; timing-safe server-password comparison
- Strict **CSP/security headers** (helmet) with Turnstile domains allow-listed
- All user content is HTML-escaped on render; links get `rel="noopener noreferrer"`; only `http(s)` URLs are linkified
- SQLite with parameterized queries everywhere; foreign keys + cascading deletes
- Secrets are never exposed via the API (masked in the owner panel), `config.json` written with `0600` permissions, atomic writes

**Recommendation:** put the server behind HTTPS (nginx/Caddy/reverse proxy or Cloudflare) — the client automatically upgrades to `wss://`. Web tokens are stored in `localStorage` of the client origin.

---

## 🗂 Project structure

```
efadro/
├── config.json            # ← all server settings live here
├── package.json
├── server/
│   ├── index.js           # entry: express + helmet + static + ws wiring
│   ├── config.js          # config loading/creation/atomic saving
│   ├── db.js              # SQLite schema (users, chats, messages, reports, audit)
│   ├── store.js           # data-access layer
│   ├── services.js        # shared chat logic + realtime fan-out
│   ├── auth.js            # JWT, gate tokens, auth middleware
│   ├── ws.js              # WebSocket hub (presence, typing, events)
│   └── routes/
│       ├── public.js      # /api/info, /api/gate
│       ├── auth.js        # signup, login, me, change-password
│       ├── chats.js       # chats + messages + reports
│       ├── users.js       # user search
│       └── admin.js       # moderation: users/reports/audit/server config
├── public/
│   ├── index.html
│   ├── css/style.css      # animated aurora UI, dark/light themes
│   └── js/app.js          # SPA: join flow, chat, staff panels
└── scripts/
    ├── smoke.mjs          # 80+ end-to-end API assertions: `npm test`
    ├── ui-test.mjs        # optional browser screenshots (needs playwright)
    └── flow-test.mjs      # optional full gate-flow test (needs playwright)
```

## 🧪 Testing

```bash
npm test            # boots an isolated server and runs 82 end-to-end assertions
```

## 🌐 API overview

```
GET  /api/info                      public server info (what gates are required)
POST /api/gate                      captcha + server password → gate token (10 min)
POST /api/auth/signup|login         (requires gate token) → access token + user
GET|PATCH /api/auth/me              profile
POST /api/auth/change-password      (keeps current device, kills others)

GET  /api/chats                     my chats w/ unread + last message
POST /api/chats/dm                  open/find DM (userId = me → Saved Messages)
POST /api/chats/group               create group
GET|PATCH /api/chats/:id            payload / rename
POST|DELETE /api/chats/:id/members… add/remove members
GET|POST /api/chats/:id/messages    history (paginated via ?before=) / send
POST /api/chats/:id/read            read receipts
PATCH|DELETE /api/messages/:id      edit (author) / delete (author or staff)
POST /api/messages/:id/report       report to moderators

GET  /api/users/search?q=           find users

GET  /api/admin/stats|users|reports|audit           moderator+ (audit: admin+)
POST /api/admin/users/:id/mute|unmute|kick           moderator+, hierarchy-checked
POST /api/admin/users/:id/ban|unban · PATCH …/role   admin+, hierarchy-checked
GET|PATCH /api/admin/server/config                   owner (persists config.json)
POST /api/admin/server/regenerate-secret             owner (signs everyone out)

WS   /ws?token=…                    frames: msg:send/typing/read/ping →
                                    msg:new, msg:edited, msg:deleted, chat:*,
                                    presence, typing, read, user:self,
                                    user:updated, server:updated, force_logout
```

## License

MIT
